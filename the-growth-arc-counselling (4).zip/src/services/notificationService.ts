/// <reference types="vite/client" />
import emailjs from '@emailjs/browser';

/**
 * Service to handle external notifications for new bookings.
 * Supports Email (via EmailJS) and Webhooks (Slack/Discord).
 */

const ADMIN_EMAIL = 'gmh3@thegrowtharccounselling.in';

interface BookingNotificationData {
  clientEmail: string;
  service: string;
  counsellorName: string;
  date: string;
  slot: string;
  amount: number;
  paymentId: string;
}

export const sendBookingNotification = async (data: BookingNotificationData) => {
  console.log('Triggering external notification for booking:', data);

  // 1. Webhook Notification (Slack/Discord)
  // If you have a Discord or Slack webhook URL, you can set it in your environment variables.
  const webhookUrl = import.meta.env.VITE_ADMIN_WEBHOOK_URL;
  if (webhookUrl) {
    try {
      await fetch(webhookUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          content: `🎉 **New Booking Confirmed!**\n\n**Client:** ${data.clientEmail}\n**Service:** ${data.service}\n**Counsellor:** ${data.counsellorName}\n**Date:** ${data.date}\n**Slot:** ${data.slot}\n**Amount:** ₹${data.amount}\n**Payment ID:** ${data.paymentId}`,
          username: 'The Growth Arc - Booking Bot'
        })
      });
      console.log('Webhook notification sent successfully');
    } catch (error) {
      console.error('Error sending webhook notification:', error);
    }
  }

  // 2. Email Notification (via EmailJS)
  // To use this, you'll need to set up an account at https://www.emailjs.com/
  const emailServiceId = import.meta.env.VITE_EMAILJS_SERVICE_ID;
  const emailTemplateId = import.meta.env.VITE_EMAILJS_TEMPLATE_ID;
  const emailPublicKey = import.meta.env.VITE_EMAILJS_PUBLIC_KEY;

  if (emailServiceId && emailTemplateId && emailPublicKey) {
    try {
      await emailjs.send(
        emailServiceId,
        emailTemplateId,
        {
          to_email: ADMIN_EMAIL,
          client_email: data.clientEmail,
          service: data.service,
          counsellor: data.counsellorName,
          date: data.date,
          slot: data.slot,
          amount: data.amount,
          payment_id: data.paymentId
        },
        emailPublicKey
      );
      console.log('Email notification sent successfully via EmailJS');
    } catch (error) {
      console.error('Error sending email notification via EmailJS:', error);
    }
  } else {
    console.warn('EmailJS credentials missing. Email notification skipped.');
  }
};
