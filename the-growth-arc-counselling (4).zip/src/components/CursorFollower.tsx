import { useEffect, useState } from 'react';
import { motion, useSpring, useMotionValue, useTransform } from 'motion/react';
import { useMood } from '../contexts/MoodContext';

export default function CursorFollower() {
  const [isHovering, setIsHovering] = useState(false);
  const [isClicking, setIsClicking] = useState(false);
  const { currentMood } = useMood();
  
  const mouseX = useMotionValue(0);
  const mouseY = useMotionValue(0);

  const springConfig = { damping: 30, stiffness: 300 };
  const x = useSpring(mouseX, springConfig);
  const y = useSpring(mouseY, springConfig);

  // Liquid stretching effect based on velocity
  const [velocity, setVelocity] = useState({ x: 0, y: 0 });

  useEffect(() => {
    let lastX = 0;
    let lastY = 0;
    let lastTime = Date.now();

    const moveCursor = (e: MouseEvent) => {
      mouseX.set(e.clientX);
      mouseY.set(e.clientY);

      const now = Date.now();
      const dt = now - lastTime;
      if (dt > 0) {
        setVelocity({
          x: (e.clientX - lastX) / dt,
          y: (e.clientY - lastY) / dt
        });
      }
      lastX = e.clientX;
      lastY = e.clientY;
      lastTime = now;
    };

    const handleHover = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      const interactive = target.closest('a, button, input, select, textarea, .interactive, .bento-item');
      setIsHovering(!!interactive);
    };

    const handleMouseDown = () => setIsClicking(true);
    const handleMouseUp = () => setIsClicking(false);

    window.addEventListener('mousemove', moveCursor);
    window.addEventListener('mouseover', handleHover);
    window.addEventListener('mousedown', handleMouseDown);
    window.addEventListener('mouseup', handleMouseUp);

    return () => {
      window.removeEventListener('mousemove', moveCursor);
      window.removeEventListener('mouseover', handleHover);
      window.removeEventListener('mousedown', handleMouseDown);
      window.removeEventListener('mouseup', handleMouseUp);
    };
  }, [mouseX, mouseY]);

  const angle = Math.atan2(velocity.y, velocity.x) * (180 / Math.PI);
  const speed = Math.sqrt(velocity.x ** 2 + velocity.y ** 2);
  const stretch = 1 + Math.min(speed * 0.5, 1.5);

  return (
    <motion.div
      className="fixed top-0 left-0 rounded-full pointer-events-none z-[9999] hidden lg:block"
      style={{
        x: x,
        y: y,
        translateX: '-50%',
        translateY: '-50%',
        backgroundColor: currentMood.color,
        width: 24,
        height: 24,
        rotate: angle,
        scaleX: isHovering ? 3 : stretch,
        scaleY: isHovering ? 3 : 1 / stretch,
        opacity: 0.2,
        mixBlendMode: 'multiply',
      }}
      animate={{
        scale: isClicking ? 0.8 : 1,
      }}
      transition={{ type: 'spring', damping: 20, stiffness: 300 }}
    />
  );
}
