import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useMood } from '../contexts/MoodContext';

export default function BackgroundMesh() {
  const { currentMood } = useMood();

  return (
    <div className="fixed inset-0 -z-20 overflow-hidden pointer-events-none">
      <AnimatePresence mode="wait">
        <motion.div
          key={currentMood.id}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 1.5, ease: "easeInOut" }}
          className="absolute inset-0"
          style={{ backgroundColor: 'rgba(252, 164, 124, 0.05)' }}
        >
          {/* Animated Mesh Gradients */}
          <div className="absolute inset-0 opacity-30">
            {currentMood.id === 'calm' && (
              <motion.div
                animate={{
                  scale: [1, 1.2, 1],
                  opacity: [0.3, 0.5, 0.3],
                }}
                transition={{
                  duration: 8,
                  repeat: Infinity,
                  ease: "easeInOut",
                }}
                className="absolute top-[-10%] left-[-10%] w-[60%] h-[60%] rounded-full blur-[60px]"
                style={{ backgroundColor: currentMood.color }}
              />
            )}

            {currentMood.id === 'overwhelmed' && (
              <div className="absolute inset-0 flex items-center justify-center">
                <motion.div
                  animate={{
                    x: [-100, 100, -100],
                    y: [-50, 50, -50],
                  }}
                  transition={{
                    duration: 20,
                    repeat: Infinity,
                    ease: "linear",
                  }}
                  className="w-[80%] h-[80%] rounded-full blur-[80px] opacity-40"
                  style={{ backgroundColor: currentMood.color }}
                />
              </div>
            )}

            {currentMood.id === 'burntout' && (
              <motion.div
                animate={{
                  opacity: [0.2, 0.4, 0.2],
                }}
                transition={{
                  duration: 10,
                  repeat: Infinity,
                  ease: "easeInOut",
                }}
                className="absolute bottom-0 left-0 right-0 h-[50%] blur-[60px]"
                style={{ 
                  background: `linear-gradient(to top, ${currentMood.color}, transparent)` 
                }}
              />
            )}

            {currentMood.id === 'anxious' && (
              <div className="absolute inset-0 grid grid-cols-2 grid-rows-2 gap-4 p-20 opacity-20">
                <div className="bg-current rounded-3xl blur-[40px]" style={{ color: currentMood.color }} />
                <div className="bg-current rounded-3xl blur-[40px] translate-y-20" style={{ color: currentMood.color }} />
                <div className="bg-current rounded-3xl blur-[40px] -translate-x-20" style={{ color: currentMood.color }} />
                <div className="bg-current rounded-3xl blur-[40px]" style={{ color: currentMood.color }} />
              </div>
            )}
          </div>
        </motion.div>
      </AnimatePresence>
      
      {/* Global Noise/Grain is already in App.tsx */}
    </div>
  );
}
