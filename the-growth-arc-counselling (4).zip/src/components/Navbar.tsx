import { Link, useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import { ShieldAlert, Smile, Frown, Zap, Coffee, Sparkles, LayoutGrid, Info, User as UserIcon, QrCode } from 'lucide-react';
import { useState, useEffect } from 'react';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';
import { useAuth } from '../contexts/AuthContext';
import { useMood, moods, MoodType } from '../contexts/MoodContext';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

const moodIcons: Record<string, React.ReactNode> = {
  calm: <Smile size={14} />,
  overwhelmed: <Frown size={14} />,
  burntout: <Coffee size={14} />,
  anxious: <Zap size={14} />,
};

const MotionLink = motion(Link);

const tooltipVariants = {
  initial: { opacity: 0, y: 10, x: '-50%', scale: 0.9, pointerEvents: 'none' as const },
  hover: { opacity: 1, y: 0, x: '-50%', scale: 1, pointerEvents: 'none' as const },
};

export default function Navbar() {
  const { currentMood, setMood } = useMood();
  const location = useLocation();
  const { user } = useAuth();

  const quickExit = () => {
    window.location.href = 'https://www.google.com';
  };

  const navItems = [
    { name: 'Home', path: '/', icon: <Smile size={20} strokeWidth={1.5} /> },
    { name: 'About', path: '/about', icon: <Info size={20} strokeWidth={1.5} /> },
    { name: 'Services', path: '/services', icon: <LayoutGrid size={20} strokeWidth={1.5} /> },
    { name: 'Team', path: '/team', icon: <UserIcon size={20} strokeWidth={1.5} /> },
    { name: 'Booking', path: '/booking', icon: <Zap size={20} strokeWidth={1.5} />, external: false },
  ];

  return (
    <>
      {/* Top Bar for Logo & Quick Exit */}
      <div className="fixed top-6 left-6 right-6 z-[100] flex justify-between items-center pointer-events-none">
        <Link to="/" className="pointer-events-auto flex items-center gap-2 group">
          <div 
            className="w-12 h-12 rounded-full flex items-center justify-center bg-cream-glass backdrop-blur-md border border-glass-border shadow-sm transition-transform hover:scale-105 overflow-hidden"
          >
            <img 
              src="https://drive.google.com/thumbnail?id=1G9rf5YwY56u9oDZkZdMGUD3xq_PWUtQ3&sz=w1000" 
              alt="The Growth Arc Counselling Logo" 
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
          </div>
        </Link>
        <motion.button
          onClick={quickExit}
          initial="initial"
          whileHover="hover"
          className="pointer-events-auto p-3 rounded-full bg-red-500/10 text-red-500/60 hover:bg-red-500 hover:text-white transition-all backdrop-blur-md border border-red-500/20 relative"
          title="Quick Exit"
        >
          <ShieldAlert size={20} strokeWidth={1.5} />
          <motion.span 
            variants={tooltipVariants}
            transition={{ duration: 0.2 }}
            className="absolute top-full left-1/2 mt-4 px-3 py-1 bg-red-500 text-white text-[10px] font-bold uppercase tracking-widest rounded-lg shadow-xl whitespace-nowrap z-[110]"
          >
            Quick Exit
          </motion.span>
        </motion.button>
      </div>

      {/* Floating Bottom Pill Navigation */}
      <nav className="fixed bottom-8 left-1/2 -translate-x-1/2 z-[100] w-auto max-w-[calc(100vw-2rem)] overflow-visible">
        <div className="bg-cream-glass backdrop-blur-xl border border-glass-border rounded-full px-3 sm:px-4 py-2 sm:py-3 flex items-center gap-1 sm:gap-2 shadow-2xl overflow-visible">
          {navItems.map((item) => {
            const isActive = location.pathname === item.path;
            const content = (
              <>
                {item.icon}
                <motion.span 
                  variants={tooltipVariants}
                  transition={{ duration: 0.2 }}
                  className="absolute bottom-full left-1/2 mb-4 px-3 py-1 bg-clay-deep text-white text-[10px] font-bold uppercase tracking-widest rounded-lg shadow-xl whitespace-nowrap z-[110]"
                >
                  {item.name}
                </motion.span>

                {isActive && (
                  <motion.div
                    layoutId="nav-glow"
                    className="absolute inset-0 rounded-full bg-terracotta-glow/10 blur-md -z-10"
                    initial={false}
                    transition={{ type: "spring", bounce: 0.2, duration: 0.6 }}
                  />
                )}
              </>
            );

            const commonProps = {
              initial: "initial",
              whileHover: "hover",
              title: item.name,
              className: cn(
                "relative p-2 sm:p-3 rounded-full transition-all duration-500 shrink-0",
                isActive 
                  ? "text-terracotta-glow bg-terracotta-soft shadow-[0_0_20px_rgba(226,114,91,0.2)]" 
                  : "text-clay-deep/60 hover:text-clay-deep hover:bg-clay-deep/5"
              )
            };

            if (item.external) {
              return (
                <motion.a 
                  key={item.path}
                  {...commonProps}
                  href={item.path}
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  {content}
                </motion.a>
              );
            }

            return (
              <MotionLink
                key={item.path}
                {...commonProps}
                to={item.path}
              >
                {content}
              </MotionLink>
            );
          })}
          
          <div className="w-px h-6 bg-clay-deep/10 mx-1 sm:mx-2 shrink-0" />

          {/* Mood Selector */}
          <motion.div 
            initial="initial"
            whileHover="hover"
            className="relative shrink-0"
          >
            <button 
              className="p-2 sm:p-3 rounded-full text-clay-deep/60 hover:text-clay-deep hover:bg-clay-deep/5 transition-all"
              title="Vibe Check"
            >
              <Sparkles size={20} strokeWidth={1.5} />
            </button>
            
            <motion.span 
              variants={tooltipVariants}
              transition={{ duration: 0.2 }}
              className="absolute bottom-full left-1/2 mb-4 px-3 py-1 bg-clay-deep text-white text-[10px] font-bold uppercase tracking-widest rounded-lg shadow-xl whitespace-nowrap z-[110]"
            >
              Vibe Check
            </motion.span>
            
            <motion.div 
              variants={{
                initial: { opacity: 0, y: 10, x: '-50%', pointerEvents: 'none' as const },
                hover: { opacity: 1, y: 0, x: '-50%', pointerEvents: 'auto' as const },
              }}
              transition={{ duration: 0.3 }}
              className="absolute bottom-full left-1/2 mb-6 z-[115]"
            >
              <div className="bg-cream-glass backdrop-blur-xl p-2 flex gap-2 border border-glass-border rounded-2xl shadow-2xl">
                {moods.map((mood) => (
                  <motion.button
                    key={mood.id}
                    onClick={() => setMood(mood.id as MoodType)}
                    initial="initial"
                    whileHover="hover"
                    title={mood.label}
                    className={cn(
                      "p-2 sm:p-3 rounded-xl transition-all hover:scale-110 relative",
                      currentMood.id === mood.id ? "bg-terracotta-soft text-terracotta-glow" : "text-clay-deep/40 hover:bg-clay-deep/5"
                    )}
                  >
                    {moodIcons[mood.id]}
                    <motion.span 
                      variants={{
                        initial: { opacity: 0, y: 5, x: '-50%', scale: 0.9, pointerEvents: 'none' as const },
                        hover: { opacity: 1, y: 0, x: '-50%', scale: 1, pointerEvents: 'none' as const },
                      }}
                      transition={{ duration: 0.2 }}
                      className="absolute bottom-full left-1/2 mb-3 px-2 py-1 bg-clay-deep text-white text-[8px] font-bold uppercase tracking-widest rounded-md shadow-lg whitespace-nowrap z-[120]"
                    >
                      {mood.label}
                    </motion.span>
                  </motion.button>
                ))}
              </div>
            </motion.div>
          </motion.div>
        </div>
      </nav>
    </>
  );
}
