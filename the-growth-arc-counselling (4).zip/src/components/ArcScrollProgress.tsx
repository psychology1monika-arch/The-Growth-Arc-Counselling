import { motion, useScroll, useSpring, useTransform } from 'motion/react';

export default function ArcScrollProgress() {
  const { scrollYProgress } = useScroll();
  
  // Create a spring for smooth progress
  const scaleX = useSpring(scrollYProgress, {
    stiffness: 100,
    damping: 30,
    restDelta: 0.001
  });

  return (
    <div className="fixed top-8 right-8 z-[100] w-24 h-24 pointer-events-none">
      <svg viewBox="0 0 100 100" className="w-full h-full transform -rotate-90">
        <defs>
          <linearGradient id="arcGradient" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#FCA47C" />
            <stop offset="100%" stopColor="#F9D779" />
          </linearGradient>
        </defs>
        {/* Background Arc */}
        <path
          d="M 20,50 A 30,30 0 1,1 80,50"
          fill="none"
          stroke="rgba(252, 164, 124, 0.1)"
          strokeWidth="2"
          strokeLinecap="round"
        />
        {/* Progress Arc */}
        <motion.path
          d="M 20,50 A 30,30 0 1,1 80,50"
          fill="none"
          stroke="url(#arcGradient)"
          strokeWidth="2"
          strokeLinecap="round"
          style={{
            pathLength: scrollYProgress,
          }}
        />
      </svg>
      <div className="absolute inset-0 flex items-center justify-center">
        <span className="text-[10px] font-mono text-cantaloupe-deep uppercase tracking-widest">
          Arc
        </span>
      </div>
    </div>
  );
}
