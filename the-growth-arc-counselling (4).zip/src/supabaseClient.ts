import { createClient } from '@supabase/supabase-js'

const supabaseUrl = 'https://udjgbstqogfdjlrqosis.supabase.co'
const supabaseKey = 'sb_publishable_CgGrvCwGxrmolkhzh56bsg_6eqEoUDi'

export const supabase = createClient(supabaseUrl, supabaseKey)
