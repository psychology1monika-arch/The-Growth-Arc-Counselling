import React, { createContext, useContext, useState, ReactNode } from 'react';

export type MoodType = 'calm' | 'overwhelmed' | 'burntout' | 'anxious';

interface MoodTheme {
  id: MoodType;
  label: string;
  color: string;
  accent: string;
  description: string;
}

export const moods: MoodTheme[] = [
  { 
    id: 'calm', 
    label: 'Calm', 
    color: '#F9D779', 
    accent: 'text-[#F9D779]',
    description: 'Soft Saffron - Finding peace in the present moment.' 
  },
  { 
    id: 'overwhelmed', 
    label: 'Overwhelmed', 
    color: '#FCA47C', 
    accent: 'text-[#FCA47C]',
    description: 'Cantaloupe Whisper - Breaking down big things into small steps.' 
  },
  { 
    id: 'burntout', 
    label: 'Burnt Out', 
    color: '#633B2B', 
    accent: 'text-[#633B2B]',
    description: 'Deep Brown - Restoring your energy and inner light.' 
  },
  { 
    id: 'anxious', 
    label: 'Anxious', 
    color: '#E67E22', 
    accent: 'text-[#E67E22]',
    description: 'Vibrant Orange - Grounding yourself when things feel uncertain.' 
  },
];

interface MoodContextType {
  currentMood: MoodTheme;
  setMood: (id: MoodType) => void;
}

const MoodContext = createContext<MoodContextType | undefined>(undefined);

export function MoodProvider({ children }: { children: ReactNode }) {
  const [currentMood, setCurrentMoodState] = useState<MoodTheme>(moods[0]);

  const setMood = (id: MoodType) => {
    const mood = moods.find(m => m.id === id);
    if (mood) {
      setCurrentMoodState(mood);
      // Update CSS variable for global use
      document.documentElement.style.setProperty('--accent-color', mood.color);
    }
  };

  return (
    <MoodContext.Provider value={{ currentMood, setMood }}>
      {children}
    </MoodContext.Provider>
  );
}

export function useMood() {
  const context = useContext(MoodContext);
  if (context === undefined) {
    throw new Error('useMood must be used within a MoodProvider');
  }
  return context;
}
