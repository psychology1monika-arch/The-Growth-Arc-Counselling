import { motion, AnimatePresence } from 'motion/react';
import { Plus, Minus } from 'lucide-react';
import { useState } from 'react';
import PageTransition from '../components/PageTransition';

const faqs = [
  {
    question: 'Is online counselling confidential?',
    answer: 'Yes, absolutely. We use secure, encrypted platforms (GMeet or Zoom) for all our sessions. Your privacy and confidentiality are our top priorities, and we adhere to strict professional ethical guidelines.'
  },
  {
    question: 'Is online therapy effective?',
    answer: 'Research shows that online therapy is just as effective as traditional face-to-face counselling for many mental health concerns. The most important factor in therapy success is the therapeutic relationship, which we focus on building regardless of the medium.'
  },
  {
    question: 'How many sessions are required?',
    answer: 'The number of sessions varies depending on your personal goals and the nature of the challenges you are facing. Typically, clients find a series of 6-8 sessions helpful for initial progress, but we work at your pace.'
  },
  {
    question: 'What platform is used for sessions?',
    answer: 'We primarily use Google Meet or Zoom. Both platforms are secure and easy to use. You will receive a link to join your session after booking.'
  },
  {
    question: 'Can couples attend online sessions?',
    answer: 'Yes, online counselling is very effective for couples. Both partners can join the session from the same location or different locations if needed.'
  },
  {
    question: 'What if I cancel my appointment?',
    answer: 'We have a 24-hour cancellation policy. If you cancel at least 24 hours in advance, we can reschedule your session. Cancellations within 24 hours may not be eligible for a refund. Please refer to our Cancellation Policy for more details.'
  }
];

export default function FAQ() {
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  return (
    <PageTransition>
      <div className="pt-20 pb-12 px-6">
        <div className="max-w-3xl mx-auto">
          <h1 className="text-5xl md:text-7xl font-serif font-bold text-cantaloupe-deep mb-8 text-center">FAQs</h1>
          <div className="space-y-4">
            {faqs.map((faq, i) => (
              <div
                key={i}
                className="bg-saffron-soft/50 backdrop-blur-sm rounded-2xl border border-glass-border overflow-hidden transition-all"
              >
                <button
                  onClick={() => setOpenIndex(openIndex === i ? null : i)}
                  className="w-full p-6 flex items-center justify-between text-left hover:bg-saffron-soft transition-colors"
                >
                  <span className="font-serif text-xl font-bold text-cantaloupe-deep">{faq.question}</span>
                  <div className="w-8 h-8 rounded-full bg-cantaloupe-solid/10 flex items-center justify-center text-cantaloupe-solid">
                    {openIndex === i ? <Minus size={18} /> : <Plus size={18} />}
                  </div>
                </button>
                <AnimatePresence>
                  {openIndex === i && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: 'auto', opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.3 }}
                    >
                      <div className="px-6 pb-6 text-cantaloupe-soft-deep/80 leading-relaxed border-t border-glass-border/50 pt-4">
                        {faq.answer}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            ))}
          </div>
        </div>
      </div>
    </PageTransition>
  );
}
