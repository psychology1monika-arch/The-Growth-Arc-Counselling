import { useState, useEffect, useCallback, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Calendar, 
  Clock, 
  User, 
  Mail, 
  Phone, 
  MessageSquare, 
  ChevronRight, 
  ChevronLeft, 
  CheckCircle2,
  Sparkles,
  Brain, 
  Target,
  Heart,
  Zap,
  Loader2,
  ShieldCheck,
  Video,
  MapPin,
  Users,
  QrCode,
  LogIn
} from 'lucide-react';
import PageTransition from '../components/PageTransition';
import { useMood } from '../contexts/MoodContext';
import { useAuth } from '../contexts/AuthContext';
import { format, addDays, startOfToday, isSameDay, isWeekend } from 'date-fns';
import { db, auth, collection, addDoc, serverTimestamp, signInWithPopup, googleProvider } from '../firebase';

enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId: string | undefined;
    email: string | null | undefined;
    emailVerified: boolean | undefined;
    isAnonymous: boolean | undefined;
    tenantId: string | null | undefined;
    providerInfo: {
      providerId: string;
      displayName: string | null;
      email: string | null;
      photoUrl: string | null;
    }[];
  }
}

function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData.map(provider => ({
        providerId: provider.providerId,
        displayName: provider.displayName,
        email: provider.email,
        photoUrl: provider.photoURL
      })) || []
    },
    operationType,
    path
  }
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

const services = [
  {
    id: 'individual',
    title: 'Individual Counselling',
    description: 'One-on-one session for personal growth and healing.',
    duration: '60 mins',
    price: 800,
    icon: <Brain size={24} />
  },
  {
    id: 'couples',
    title: 'Couple Counselling',
    description: 'Strengthen your relationship and improve communication.',
    duration: '90 mins',
    price: 1500,
    icon: <Heart size={24} />
  },
  {
    id: 'workshop',
    title: 'Workshops',
    description: 'Group sessions focusing on specific wellness topics.',
    duration: 'Varies',
    price: 0,
    icon: <Users size={24} />
  }
];

const counsellors = [
  {
    id: 'gadadhar',
    name: 'Gadadhar',
    role: 'Founder & Counselling Psychologist',
    img: 'https://drive.google.com/thumbnail?id=1rlhdjjDxOC1qz82rF469wQt9iwFqeAZS&sz=w1000'
  },
  {
    id: 'haritaa',
    name: 'Haritaa. L.G',
    role: 'Counselling Psychologist',
    img: 'https://drive.google.com/thumbnail?id=18E72XwEX1ViaPCrgsJ6DYk_J7xL8XEKm&sz=w1000'
  },
  {
    id: 'monika',
    name: 'Monika. V',
    role: 'Counselling Psychologist',
    img: 'https://drive.google.com/thumbnail?id=1LkYsEgIvsyjhVfwtIhJR3K-qhAMJu-OW&sz=w1000'
  }
];

const timeSlots = [
  '09:00 AM', '10:00 AM', '11:00 AM', 
  '02:00 PM', '03:00 PM', '04:00 PM', '05:00 PM'
];

export default function Booking() {
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    service: '',
    counsellor: '',
    date: null as Date | null,
    time: '',
    name: '',
    email: '',
    phone: '',
    message: '',
    mode: 'online' as 'online' | 'offline'
  });
  const { currentMood } = useMood();
  const { user, loading: authLoading } = useAuth();

  const handleLogin = async () => {
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (error) {
      console.error('Login failed:', error);
      setSubmitError('Failed to sign in. Please try again.');
    }
  };

  const handleNext = () => {
    console.log('Moving from step:', step, 'to:', step + 1);
    if (formData.service === 'workshop' && step === 1) {
      setStep(10); // Special step for workshops
    } else if (step < 4) {
      setStep(prev => prev + 1);
    }
  };
  
  const handleBack = () => {
    console.log('Moving back from step:', step);
    if (step === 10) {
      setStep(1);
    } else {
      setStep(prev => Math.max(1, prev - 1));
    }
  };

  const handleSubmit = async (e: React.MouseEvent) => {
    e.preventDefault();
    if (!user) {
      setSubmitError("Please sign in to complete your booking.");
      return;
    }

    console.log('Submitting booking from step:', step);
    setLoading(true);
    setSubmitError(null);
    
    try {
      const path = 'appointments';
      await addDoc(collection(db, path), {
        clientUid: user.uid,
        clientEmail: user.email,
        clientName: formData.name,
        clientPhone: formData.phone,
        counsellorId: formData.counsellor,
        counsellorName: selectedCounsellor?.name,
        service: formData.service,
        date: formData.date ? format(formData.date, 'yyyy-MM-dd') : null,
        slot: formData.time,
        status: 'pending',
        amount: selectedService?.price || 0,
        paymentStatus: 'pending',
        message: formData.message,
        mode: formData.mode,
        createdAt: serverTimestamp()
      });

      setLoading(false);
      setStep(5); // Success step
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, 'appointments');
    }
  };

  const isStepValid = () => {
    const isValid = (() => {
      switch (step) {
        case 1: return !!formData.service;
        case 2: return !!formData.counsellor;
        case 3: return !!formData.name && !!formData.email && !!formData.phone && !!formData.date && !!formData.time && !!user;
        default: return true;
      }
    })();
    return isValid;
  };

  const selectedService = services.find(s => s.id === formData.service);
  const selectedCounsellor = counsellors.find(c => c.id === formData.counsellor);

  console.log('Rendering Booking Page - Current Step:', step);

  return (
    <PageTransition>
      <div className="min-h-screen bg-cantaloupe-whisper pt-32 pb-20 px-6">
        <div className="max-w-4xl mx-auto">
          {/* Header */}
          <div className="text-center mb-12">
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-cantaloupe-solid/10 text-cantaloupe-solid text-sm font-bold mb-6"
            >
              <Zap size={16} />
              <span>{step === 10 ? 'Enquiry' : step === 5 ? 'Success' : `Step ${step} of 3`}</span>
            </motion.div>
            <h1 className="text-4xl md:text-6xl font-serif font-bold text-cantaloupe-deep mb-4">
              Book Your <span className="italic" style={{ color: currentMood.color }}>Session</span>
            </h1>
            <p className="text-cantaloupe-soft-deep/60 max-w-xl mx-auto">
              Take the first step toward a more balanced and fulfilling life.
            </p>
          </div>

          {/* Booking Container */}
          <div className="bg-white rounded-[48px] shadow-2xl shadow-cantaloupe-soft-deep/5 border border-glass-border overflow-hidden">
            <div className="flex flex-col md:flex-row min-h-[600px]">
              {/* Sidebar Info */}
              <div className="md:w-1/3 bg-cantaloupe-whisper/50 p-12 border-r border-glass-border">
                <div className="space-y-8">
                  <div>
                    <h3 className="text-xs uppercase tracking-widest font-bold text-cantaloupe-soft-deep/40 mb-6">Your Selection</h3>
                    <div className="space-y-4">
                      {formData.service && (
                        <div className="flex items-center gap-3 text-cantaloupe-deep font-medium">
                          <div className="w-8 h-8 rounded-xl bg-white flex items-center justify-center shadow-sm">
                            <Brain size={16} className="text-cantaloupe-solid" />
                          </div>
                          {selectedService?.title}
                        </div>
                      )}
                      {formData.counsellor && (
                        <div className="flex items-center gap-3 text-cantaloupe-deep font-medium">
                          <div className="w-8 h-8 rounded-xl bg-white flex items-center justify-center shadow-sm">
                            <User size={16} className="text-cantaloupe-solid" />
                          </div>
                          {selectedCounsellor?.name}
                        </div>
                      )}
                      {formData.date && (
                        <div className="flex items-center gap-3 text-cantaloupe-deep font-medium">
                          <div className="w-8 h-8 rounded-xl bg-white flex items-center justify-center shadow-sm">
                            <Calendar size={16} className="text-cantaloupe-solid" />
                          </div>
                          {format(formData.date, 'MMM do, yyyy')}
                        </div>
                      )}
                      {formData.time && (
                        <div className="flex items-center gap-3 text-cantaloupe-deep font-medium">
                          <div className="w-8 h-8 rounded-xl bg-white flex items-center justify-center shadow-sm">
                            <Clock size={16} className="text-cantaloupe-solid" />
                          </div>
                          {formData.time}
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="pt-8 border-t border-glass-border">
                    <div className="flex items-center gap-3 text-sm text-cantaloupe-soft-deep/60">
                      <ShieldCheck size={16} className="text-emerald-500" />
                      Secure & Confidential
                    </div>
                  </div>
                </div>
              </div>

              {/* Form Content */}
              <div className="flex-1 p-12 relative">
                <AnimatePresence mode="wait">
                  {step === 1 && (
                    <motion.div
                      key="step1"
                      initial={{ opacity: 0, x: 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: -20 }}
                      className="h-full flex flex-col"
                    >
                      <h2 className="text-2xl font-serif font-bold text-cantaloupe-deep mb-8">Choose a Service</h2>
                      <div className="grid gap-4 flex-1">
                        {services.map((service) => (
                          <button
                            key={service.id}
                            onClick={() => {
                              setFormData({ ...formData, service: service.id });
                              if (service.id === 'workshop') {
                                setStep(10);
                              } else {
                                setStep(2);
                              }
                            }}
                            className={`flex items-center gap-6 p-6 rounded-3xl border-2 transition-all duration-300 text-left ${
                              formData.service === service.id
                                ? 'border-cantaloupe-solid bg-cantaloupe-solid/5'
                                : 'border-glass-border hover:border-cantaloupe-solid/30 bg-white'
                            }`}
                          >
                            <div className={`w-12 h-12 rounded-2xl flex items-center justify-center transition-colors ${
                              formData.service === service.id ? 'bg-cantaloupe-solid text-white' : 'bg-cantaloupe-whisper text-cantaloupe-soft-deep'
                            }`}>
                              {service.icon}
                            </div>
                            <div className="flex-1">
                              <h3 className="font-bold text-cantaloupe-deep">{service.title}</h3>
                              <p className="text-sm text-cantaloupe-soft-deep/60">{service.description}</p>
                            </div>
                            <div className="text-right">
                              <div className="font-bold text-cantaloupe-solid">{service.price > 0 ? `₹${service.price}` : 'Enquiry'}</div>
                              <div className="text-xs text-cantaloupe-soft-deep/40">{service.duration}</div>
                            </div>
                          </button>
                        ))}
                      </div>
                    </motion.div>
                  )}

                  {step === 2 && (
                    <motion.div
                      key="step2"
                      initial={{ opacity: 0, x: 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: -20 }}
                      className="h-full flex flex-col"
                    >
                      <h2 className="text-2xl font-serif font-bold text-cantaloupe-deep mb-8">Choose a Counsellor</h2>
                      <div className="grid gap-4 flex-1">
                        {counsellors.map((counsellor) => (
                          <button
                            key={counsellor.id}
                            onClick={() => {
                              setFormData({ ...formData, counsellor: counsellor.id });
                              setStep(3);
                            }}
                            className={`flex items-center gap-6 p-6 rounded-3xl border-2 transition-all duration-300 text-left ${
                              formData.counsellor === counsellor.id
                                ? 'border-cantaloupe-solid bg-cantaloupe-solid/5'
                                : 'border-glass-border hover:border-cantaloupe-solid/30 bg-white'
                            }`}
                          >
                            <div className="w-16 h-16 rounded-2xl overflow-hidden shadow-md">
                              <img src={counsellor.img} alt={counsellor.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                            </div>
                            <div className="flex-1">
                              <h3 className="font-bold text-cantaloupe-deep">{counsellor.name}</h3>
                              <p className="text-sm text-cantaloupe-soft-deep/60">{counsellor.role}</p>
                            </div>
                          </button>
                        ))}
                      </div>
                    </motion.div>
                  )}

                  {step === 3 && (
                    <motion.div
                      key="step3"
                      initial={{ opacity: 0, x: 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: -20 }}
                      className="h-full flex flex-col"
                    >
                      <h2 className="text-2xl font-serif font-bold text-cantaloupe-deep mb-8">Booking Details & Payment</h2>
                      <div className="space-y-8 flex-1 overflow-y-auto pr-2 custom-scrollbar">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                          <div className="space-y-2">
                            <label className="text-sm font-bold text-cantaloupe-soft-deep">Selected Service</label>
                            <input
                              type="text"
                              readOnly
                              value={selectedService?.title}
                              className="w-full px-4 py-4 rounded-2xl bg-cantaloupe-whisper/50 border-none text-cantaloupe-soft-deep/60 cursor-not-allowed"
                            />
                          </div>
                          <div className="space-y-2">
                            <label className="text-sm font-bold text-cantaloupe-soft-deep">Selected Counsellor</label>
                            <input
                              type="text"
                              readOnly
                              value={selectedCounsellor?.name}
                              className="w-full px-4 py-4 rounded-2xl bg-cantaloupe-whisper/50 border-none text-cantaloupe-soft-deep/60 cursor-not-allowed"
                            />
                          </div>
                          <div className="space-y-2">
                            <label className="text-sm font-bold text-cantaloupe-soft-deep">Full Name</label>
                            <div className="relative">
                              <User className="absolute left-4 top-1/2 -translate-y-1/2 text-cantaloupe-soft-deep/40" size={18} />
                              <input
                                type="text"
                                value={formData.name}
                                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                                className="w-full pl-12 pr-4 py-4 rounded-2xl bg-cantaloupe-whisper border-none focus:ring-2 focus:ring-cantaloupe-solid transition-all"
                                placeholder="John Doe"
                              />
                            </div>
                          </div>
                          <div className="space-y-2">
                            <label className="text-sm font-bold text-cantaloupe-soft-deep">Email Address</label>
                            <div className="relative">
                              <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-cantaloupe-soft-deep/40" size={18} />
                              <input
                                type="email"
                                value={formData.email}
                                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                                className="w-full pl-12 pr-4 py-4 rounded-2xl bg-cantaloupe-whisper border-none focus:ring-2 focus:ring-cantaloupe-solid transition-all"
                                placeholder="john@example.com"
                              />
                            </div>
                          </div>
                          <div className="space-y-2">
                            <label className="text-sm font-bold text-cantaloupe-soft-deep">Phone Number</label>
                            <div className="relative">
                              <Phone className="absolute left-4 top-1/2 -translate-y-1/2 text-cantaloupe-soft-deep/40" size={18} />
                              <input
                                type="tel"
                                value={formData.phone}
                                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                                className="w-full pl-12 pr-4 py-4 rounded-2xl bg-cantaloupe-whisper border-none focus:ring-2 focus:ring-cantaloupe-solid transition-all"
                                placeholder="+91 98765 43210"
                              />
                            </div>
                          </div>
                          <div className="space-y-2">
                            <label className="text-sm font-bold text-cantaloupe-soft-deep">Message (Optional)</label>
                            <div className="relative">
                              <MessageSquare className="absolute left-4 top-4 text-cantaloupe-soft-deep/40" size={18} />
                              <textarea
                                value={formData.message}
                                onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                                className="w-full pl-12 pr-4 py-4 rounded-2xl bg-cantaloupe-whisper border-none focus:ring-2 focus:ring-cantaloupe-solid transition-all min-h-[120px]"
                                placeholder="Anything you'd like us to know..."
                              />
                            </div>
                          </div>
                        </div>

                        <div className="pt-8 border-t border-glass-border">
                          <h3 className="text-xs uppercase tracking-widest font-bold text-cantaloupe-soft-deep/40 mb-6">Select Date & Time</h3>
                          
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                            <div>
                              <h4 className="text-[10px] uppercase tracking-widest font-bold text-cantaloupe-soft-deep/40 mb-4">Available Dates</h4>
                              <div className="grid grid-cols-7 gap-2">
                                {[...Array(14)].map((_, i) => {
                                  const date = addDays(startOfToday(), i);
                                  const isSelected = formData.date && isSameDay(date, formData.date);
                                  const isOff = isWeekend(date);
                                  
                                  return (
                                    <button
                                      key={i}
                                      disabled={isOff}
                                      onClick={() => setFormData({ ...formData, date })}
                                      className={`aspect-square rounded-xl flex flex-col items-center justify-center text-[10px] transition-all ${
                                        isSelected 
                                          ? 'bg-cantaloupe-solid text-white shadow-lg' 
                                          : isOff
                                            ? 'bg-gray-50 text-gray-300 cursor-not-allowed'
                                            : 'bg-cantaloupe-whisper text-cantaloupe-soft-deep hover:bg-cantaloupe-solid/10'
                                      }`}
                                    >
                                      <span className="opacity-60">{format(date, 'EEE')}</span>
                                      <span className="font-bold">{format(date, 'd')}</span>
                                    </button>
                                  );
                                })}
                              </div>
                            </div>

                            <div>
                              <h4 className="text-[10px] uppercase tracking-widest font-bold text-cantaloupe-soft-deep/40 mb-4">Available Slots</h4>
                              <div className="grid grid-cols-2 gap-3">
                                {timeSlots.map((slot) => (
                                  <button
                                    key={slot}
                                    onClick={() => setFormData({ ...formData, time: slot })}
                                    className={`p-3 rounded-xl text-sm font-medium transition-all ${
                                      formData.time === slot
                                        ? 'bg-cantaloupe-solid text-white shadow-lg'
                                        : 'bg-cantaloupe-whisper text-cantaloupe-soft-deep hover:bg-cantaloupe-solid/10'
                                    }`}
                                  >
                                    {slot}
                                  </button>
                                ))}
                              </div>
                            </div>
                          </div>
                        </div>

                        {/* Payment Section Integrated into Step 3 */}
                        <div className="pt-8 border-t border-glass-border">
                          <h3 className="text-2xl font-serif font-bold text-cantaloupe-deep mb-8">Payment & Confirmation</h3>
                          <div className="bg-cantaloupe-whisper p-8 rounded-3xl space-y-6 text-center">
                            <div className="space-y-2 mb-6">
                              <p className="text-xs uppercase tracking-widest font-bold text-cantaloupe-soft-deep/40">Total Amount to Pay</p>
                              <p className="text-5xl font-serif font-bold text-cantaloupe-solid">₹{selectedService?.price}</p>
                            </div>
                            
                            <div className="max-w-[280px] mx-auto p-6 bg-white rounded-3xl shadow-xl border border-glass-border mb-6">
                              <div className="relative aspect-square w-full bg-cantaloupe-whisper rounded-2xl overflow-hidden flex items-center justify-center">
                                <img 
                                  src="https://lh3.googleusercontent.com/d/1njTa1g00q_CfrluTtCu2FFa0w8Q3blF5"
                                  alt="Payment QR Code" 
                                  className="w-full h-full object-contain"
                                  referrerPolicy="no-referrer"
                                  onLoad={() => console.log('QR Code loaded successfully')}
                                  onError={(e) => {
                                    console.error('QR Code failed to load, trying fallback URL');
                                    const target = e.target as HTMLImageElement;
                                    if (target.src !== 'https://drive.google.com/uc?export=view&id=1njTa1g00q_CfrluTtCu2FFa0w8Q3blF5') {
                                      target.src = 'https://drive.google.com/uc?export=view&id=1njTa1g00q_CfrluTtCu2FFa0w8Q3blF5';
                                    }
                                  }}
                                />
                              </div>
                              <div className="mt-4 flex flex-col items-center gap-2">
                                <p className="text-[10px] font-bold text-cantaloupe-soft-deep/40 uppercase tracking-widest">Scan to Pay via UPI</p>
                                <div className="w-8 h-1 bg-cantaloupe-solid/20 rounded-full" />
                              </div>
                            </div>

                            <div className="text-sm text-cantaloupe-soft-deep/60 space-y-3 max-w-sm mx-auto">
                              {!user ? (
                                <div className="p-6 bg-amber-50 rounded-3xl border border-amber-100 space-y-4">
                                  <p className="font-medium text-amber-800">Please sign in to confirm your booking</p>
                                  <button
                                    onClick={handleLogin}
                                    className="w-full flex items-center justify-center gap-2 px-6 py-3 bg-white text-cantaloupe-deep font-bold rounded-2xl shadow-sm hover:shadow-md transition-all border border-amber-200"
                                  >
                                    <LogIn size={18} /> Sign in with Google
                                  </button>
                                </div>
                              ) : (
                                <>
                                  <div className="flex items-start gap-3 text-left bg-white/50 p-4 rounded-2xl border border-glass-border">
                                    <div className="w-6 h-6 rounded-full bg-cantaloupe-solid text-white flex items-center justify-center flex-shrink-0 text-xs font-bold">1</div>
                                    <p>Scan the QR code using any UPI app (GPay, PhonePe, etc.)</p>
                                  </div>
                                  <div className="flex items-start gap-3 text-left bg-white/50 p-4 rounded-2xl border border-glass-border">
                                    <div className="w-6 h-6 rounded-full bg-cantaloupe-solid text-white flex items-center justify-center flex-shrink-0 text-xs font-bold">2</div>
                                    <p>Enter the amount: <span className="font-bold text-cantaloupe-solid">₹{selectedService?.price}</span></p>
                                  </div>
                                  <div className="flex items-start gap-3 text-left bg-white/50 p-4 rounded-2xl border border-glass-border">
                                    <div className="w-6 h-6 rounded-full bg-cantaloupe-solid text-white flex items-center justify-center flex-shrink-0 text-xs font-bold">3</div>
                                    <p>Once paid, click <span className="font-bold text-cantaloupe-solid">Confirm Payment</span> below.</p>
                                  </div>
                                </>
                              )}
                            </div>

                            {submitError && (
                              <div className="p-4 bg-red-50 text-red-500 rounded-2xl text-sm font-medium border border-red-100 animate-shake">
                                {submitError}
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  )}

                  {step === 5 && (
                    <motion.div
                      key="success"
                      initial={{ opacity: 0, scale: 0.9 }}
                      animate={{ opacity: 1, scale: 1 }}
                      className="h-full flex flex-col items-center justify-center text-center p-12"
                    >
                      <div className="w-24 h-24 bg-emerald-100 text-emerald-500 rounded-full flex items-center justify-center mb-8">
                        <CheckCircle2 size={48} />
                      </div>
                      <h2 className="text-3xl font-serif font-bold text-cantaloupe-deep mb-4">Booking Confirmed!</h2>
                      <p className="text-cantaloupe-soft-deep/60 mb-12 max-w-sm">
                        Thank you for choosing The Growth Arc. We've received your booking and payment confirmation. We will reach out to you shortly.
                      </p>
                      <button 
                        onClick={() => window.location.href = '/'}
                        className="btn-primary"
                      >
                        Return Home
                      </button>
                    </motion.div>
                  )}

                  {step === 10 && (
                    <motion.div
                      key="workshop"
                      initial={{ opacity: 0, x: 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: -20 }}
                      className="h-full flex flex-col items-center justify-center text-center p-12"
                    >
                      <div className="w-20 h-20 bg-cantaloupe-solid/10 text-cantaloupe-solid rounded-3xl flex items-center justify-center mb-8">
                        <Mail size={40} />
                      </div>
                      <h2 className="text-3xl font-serif font-bold text-cantaloupe-deep mb-4">Workshop Enquiry</h2>
                      <p className="text-cantaloupe-soft-deep/60 mb-8 max-w-sm">
                        For workshop bookings and enquiries, please reach out to us via email. We'd love to discuss how we can bring our wellness sessions to your group.
                      </p>
                      <div className="p-6 bg-white rounded-3xl border border-glass-border shadow-sm mb-12">
                        <p className="text-xs uppercase tracking-widest font-bold text-cantaloupe-soft-deep/40 mb-2">Email Us At</p>
                        <a href="mailto:gmh3@thegrowtharccounselling.in" className="text-xl font-bold text-cantaloupe-solid hover:underline">
                          gmh3@thegrowtharccounselling.in
                        </a>
                      </div>
                      <button 
                        onClick={() => setStep(1)}
                        className="text-cantaloupe-soft-deep font-bold hover:text-cantaloupe-deep transition-colors"
                      >
                        Back to Services
                      </button>
                    </motion.div>
                  )}
                </AnimatePresence>

                {/* Navigation Buttons */}
                {step < 5 && step !== 10 && (
                  <div className="mt-12 flex items-center justify-between">
                    <button
                      onClick={handleBack}
                      disabled={step === 1}
                      className={`flex items-center gap-2 font-bold text-cantaloupe-soft-deep transition-all ${
                        step === 1 ? 'opacity-0 pointer-events-none' : 'hover:text-cantaloupe-deep'
                      }`}
                    >
                      <ChevronLeft size={20} /> Back
                    </button>
                    
                    {step === 3 ? (
                      <button
                        onClick={handleSubmit}
                        disabled={loading || !isStepValid()}
                        className={`btn-primary min-w-[200px] flex items-center justify-center gap-3 ${
                          loading || !isStepValid() ? 'opacity-50 cursor-not-allowed' : ''
                        }`}
                      >
                        {loading ? (
                          <Loader2 className="animate-spin" size={20} />
                        ) : (
                          <>Confirm Payment <CheckCircle2 size={20} /></>
                        )}
                      </button>
                    ) : (
                      <button
                        onClick={handleNext}
                        disabled={!isStepValid()}
                        className={`btn-primary min-w-[200px] flex items-center justify-center gap-3 ${
                          !isStepValid() ? 'opacity-50 cursor-not-allowed' : ''
                        }`}
                      >
                        Continue <ChevronRight size={20} />
                      </button>
                    )}
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Trust Badges */}
          <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="flex items-center gap-4 text-cantaloupe-soft-deep/60">
              <div className="w-10 h-10 rounded-full bg-white flex items-center justify-center shadow-sm">
                <ShieldCheck size={20} className="text-emerald-500" />
              </div>
              <span className="text-sm font-medium">100% Confidential</span>
            </div>
            <div className="flex items-center gap-4 text-cantaloupe-soft-deep/60">
              <div className="w-10 h-10 rounded-full bg-white flex items-center justify-center shadow-sm">
                <Users size={20} className="text-blue-500" />
              </div>
              <span className="text-sm font-medium">Expert Guidance</span>
            </div>
            <div className="flex items-center gap-4 text-cantaloupe-soft-deep/60">
              <div className="w-10 h-10 rounded-full bg-white flex items-center justify-center shadow-sm">
                <Sparkles size={20} className="text-amber-500" />
              </div>
              <span className="text-sm font-medium">Personalized Care</span>
            </div>
          </div>
        </div>
      </div>
    </PageTransition>
  );
}
