import { motion, useScroll, useSpring, useTransform, AnimatePresence } from 'motion/react';
import { useRef, useState } from 'react';
import { Sparkles, X, Share2, Bookmark, Zap } from 'lucide-react';
import PageTransition from '../components/PageTransition';
import { DoodleArc, DoodleSparkle, DoodleBrain, DoodleHeart } from '../components/Doodles';
import { useMood } from '../contexts/MoodContext';

const posts = [
  {
    id: 1,
    title: 'The Future of Healing: Why Online Counselling is Transforming Mental Health Support',
    excerpt: 'Online counselling is no longer just a convenience; it is a powerful tool for accessibility and personalized care.',
    content: 'Online counselling is no longer just a convenience; it is a powerful tool for accessibility and personalized care. In an increasingly digital world, the ability to connect with a professional from the comfort of your own space can break down significant barriers to entry. Whether it\'s the stigma associated with visiting a clinic, physical mobility issues, or simply a busy schedule, digital therapy offers a flexible and effective alternative.',
    date: 'Oct 12, 2023',
    readTime: '5 min read',
    category: 'Mental Health',
    img: 'https://images.unsplash.com/photo-1518173946687-a4c8892bbd9f?auto=format&fit=crop&q=80&w=800&fm=webp',
    doodle: DoodleArc
  },
  {
    id: 2,
    title: 'How to Deal With Constant Overthinking',
    excerpt: 'Have you ever replayed a conversation again and again in your mind? Your thoughts keep running in circles, and before you realize it, you feel mentally exhausted.',
    content: `Have you ever replayed a conversation again and again in your mind? Maybe you keep wondering, “Did I say something wrong?” or “What if things go badly tomorrow?” Your thoughts keep running in circles, and before you realize it, you feel mentally exhausted.`,
    date: 'Mar 17, 2026',
    readTime: '6 min read',
    category: 'Mental Health',
    img: 'https://images.unsplash.com/photo-1506126613408-eca07ce68773?auto=format&fit=crop&q=80&w=800&fm=webp',
    doodle: DoodleBrain
  },
  {
    id: 3,
    title: 'Navigating Identity in Your 20s',
    excerpt: 'The "quarter-life crisis" is real, but it is also a fertile ground for self-discovery and growth.',
    content: 'The "quarter-life crisis" is real, but it is also a fertile ground for self-discovery and growth. Early adulthood is a period of intense transition. From finishing education to starting a career and navigating complex relationships, the pressure to "have it all figured out" can be overwhelming. However, this uncertainty is also an invitation to explore who you truly are, independent of societal expectations.',
    date: 'Sep 28, 2023',
    readTime: '7 min read',
    category: 'Self-Growth',
    img: 'https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&q=80&w=800&fm=webp',
    doodle: DoodleSparkle
  },
  {
    id: 4,
    title: 'Burnout Prevention for Professionals',
    excerpt: 'Practical strategies to maintain your mental well-being in a high-pressure work environment.',
    content: 'Practical strategies to maintain your mental well-being in a high-pressure work environment. Burnout is more than just being tired. It\'s a state of emotional, physical, and mental exhaustion caused by excessive and prolonged stress. In today\'s "always-on" culture, setting boundaries is not just a luxury—it\'s a necessity for survival and long-term success.',
    date: 'Sep 15, 2023',
    readTime: '6 min read',
    category: 'Workplace',
    img: 'https://images.unsplash.com/photo-1501004318641-b39e6451bec6?auto=format&fit=crop&q=80&w=800&fm=webp',
    doodle: DoodleBrain
  },
  {
    id: 5,
    title: 'The Power of Vulnerability',
    excerpt: 'Embracing our imperfections is the key to authentic connection and inner peace.',
    content: 'Embracing our imperfections is the key to authentic connection and inner peace. Vulnerability is often mistaken for weakness, but in reality, it is our greatest measure of courage. When we allow ourselves to be seen—truly seen—we open the door to deeper relationships and a more profound sense of belonging.',
    date: 'Aug 22, 2023',
    readTime: '8 min read',
    category: 'Emotional Wellness',
    img: 'https://images.unsplash.com/photo-1515549832467-8783363e19b6?auto=format&fit=crop&q=80&w=800&fm=webp',
    doodle: DoodleHeart
  }
];

const BlogCard = ({ post, index, total }: { post: any, index: number, total: number }) => {
  const { currentMood } = useMood();
  const cardRef = useRef(null);
  
  const { scrollYProgress } = useScroll({
    target: cardRef,
    offset: ["start end", "start start"]
  });

  const scale = useTransform(scrollYProgress, [0, 1], [0.8, 1]);
  const opacity = useTransform(scrollYProgress, [0, 0.5], [0, 1]);
  const y = useTransform(scrollYProgress, [0, 1], [100, 0]);

  return (
    <motion.div
      ref={cardRef}
      style={{ 
        scale, 
        opacity, 
        y,
        zIndex: index,
      }}
      className="sticky top-24 w-full max-w-4xl mx-auto mb-12"
    >
      <div className="glass-card overflow-hidden group cursor-pointer bg-saffron-soft/50 border-glass-border">
        <div className="grid md:grid-cols-2 gap-0">
          <div className="relative aspect-square md:aspect-auto overflow-hidden">
            <img 
              src={post.img} 
              alt={post.title} 
              className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-1000 group-hover:scale-110"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-saffron-soft/80 to-transparent" />
            <div className="absolute top-8 left-8">
              <post.doodle className="w-12 h-12 opacity-40 group-hover:opacity-100 transition-opacity" style={{ color: currentMood.color }} />
            </div>
          </div>
          
          <div className="p-12 flex flex-col justify-between bg-saffron-soft/80 backdrop-blur-xl">
            <div className="space-y-6">
              <div className="flex items-center gap-4 text-[10px] font-bold uppercase tracking-[0.3em]" style={{ color: currentMood.color }}>
                <span>{post.category}</span>
                <span className="w-1 h-1 rounded-full bg-cantaloupe-deep/20" />
                <span>{post.readTime}</span>
              </div>
              <h2 className="text-3xl md:text-5xl font-serif font-bold text-cantaloupe-deep leading-tight group-hover:animate-[chromatic_2s_infinite]">
                {post.title}
              </h2>
              <p className="text-cantaloupe-soft-deep/60 text-sm leading-relaxed line-clamp-3">
                {post.excerpt}
              </p>
            </div>
            
            <div className="pt-8 flex items-center justify-between border-t border-glass-border/50">
              <span className="text-[10px] font-mono text-cantaloupe-soft-deep/40 uppercase tracking-widest">{post.date}</span>
              <button className="flex items-center gap-2 text-[10px] font-bold uppercase tracking-widest text-cantaloupe-deep group-hover:text-cantaloupe-solid transition-colors">
                Read More <Zap size={12} style={{ color: currentMood.color }} />
              </button>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
};

export default function Blog() {
  const { currentMood } = useMood();
  const { scrollYProgress } = useScroll();
  
  const scaleX = useSpring(scrollYProgress, {
    stiffness: 100,
    damping: 30,
    restDelta: 0.001
  });

  return (
    <PageTransition>
      <div className="min-h-screen bg-cantaloupe-whisper pt-32 pb-20 relative">
        {/* Reading Progress Bar (Mood Colored) */}
        <motion.div 
          className="fixed top-0 left-0 right-0 h-1 z-[100] origin-left"
          style={{ 
            scaleX,
            backgroundColor: currentMood.color,
            boxShadow: `0 0 20px ${currentMood.color}66`
          }}
        />

        <div className="max-w-7xl mx-auto px-6">
          <div className="mb-32 text-center max-w-3xl mx-auto">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
            >
              <div className="inline-flex items-center gap-2 px-4 py-2 bg-cantaloupe-solid/10 text-cantaloupe-solid rounded-full text-[10px] font-bold uppercase tracking-[0.3em] mb-8">
                <Sparkles size={14} style={{ color: currentMood.color }} />
                <span>Journal Club</span>
              </div>
              <h1 className="text-6xl md:text-9xl font-serif font-bold text-cantaloupe-deep mb-8 leading-[0.85] tracking-tighter">
                Reflections on the <span className="italic" style={{ color: currentMood.color }}>Arc</span>.
              </h1>
              <p className="text-cantaloupe-soft-deep/60 text-xl leading-relaxed">
                A collection of thoughts, research, and stories to help you navigate 
                your own journey of growth and self-discovery.
              </p>
            </motion.div>
          </div>

          {/* Infinite Stack Section */}
          <div className="relative">
            {posts.map((post, i) => (
              <BlogCard key={post.id} post={post} index={i} total={posts.length} />
            ))}
          </div>
          
          <div className="py-20 flex items-center justify-center">
            <motion.div 
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              className="text-center"
            >
              <h3 className="text-2xl font-serif italic text-cantaloupe-deep/20">End of the current arc.</h3>
              <p className="text-[10px] font-bold uppercase tracking-[0.4em] text-cantaloupe-solid mt-4">More reflections coming soon</p>
            </motion.div>
          </div>
        </div>
      </div>
    </PageTransition>
  );
}
