import { motion } from 'motion/react';
import { Shield, Heart, Scale, ArrowRight } from 'lucide-react';
import PageTransition from '../components/PageTransition';

export default function About() {
  return (
    <PageTransition>
      <div className="pt-20 pb-12">
        {/* Hero */}
        <section className="px-6 mb-16">
          <div className="max-w-4xl mx-auto text-center">
            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-5xl md:text-7xl font-serif font-bold text-cantaloupe-deep mb-8"
            >
              About The Growth Arc Counselling
            </motion.h1>
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="text-2xl text-cantaloupe-soft-deep/80 font-serif italic leading-relaxed"
            >
              "Therapy is not about fixing what is broken. It is about understanding yourself more deeply."
            </motion.p>
          </div>
        </section>

        {/* Philosophy */}
        <section className="section-padding bg-cantaloupe-whisper">
          <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-20 items-center">
            <div className="order-2 lg:order-1 relative h-[400px] md:h-[600px]">
              {/* Stacked Images Effect */}
              <motion.div 
                initial={{ rotate: -5, x: -20 }}
                whileInView={{ rotate: -8, x: -40 }}
                className="absolute top-10 left-10 w-full h-full rounded-[40px] overflow-hidden shadow-xl z-10 border-4 border-white"
              >
                <img
                  src="https://images.unsplash.com/photo-1499209974431-9dac3adaf471?auto=format&fit=crop&q=80&w=800"
                  alt="Nature growth 1"
                  className="w-full h-full object-cover grayscale opacity-50"
                  referrerPolicy="no-referrer"
                />
              </motion.div>
              <motion.div 
                initial={{ rotate: 5, x: 20 }}
                whileInView={{ rotate: 8, x: 40 }}
                className="absolute top-5 left-5 w-full h-full rounded-[40px] overflow-hidden shadow-2xl z-20 border-4 border-white"
              >
                <img
                  src="https://images.unsplash.com/photo-1518173946687-a4c8892bbd9f?auto=format&fit=crop&q=80&w=800"
                  alt="Nature growth 2"
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              </motion.div>
              <motion.div 
                initial={{ y: 20 }}
                whileInView={{ y: 0 }}
                className="absolute inset-0 w-full h-full rounded-[40px] overflow-hidden shadow-2xl z-30 border-4 border-white"
              >
                <img
                  src="https://images.unsplash.com/photo-1506126613408-eca07ce68773?auto=format&fit=crop&q=80&w=1000"
                  alt="Nature growth 3"
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              </motion.div>
            </div>
            <div className="order-1 lg:order-2">
              <h2 className="text-4xl font-serif font-bold text-cantaloupe-deep mb-8">Our Philosophy</h2>
              <div className="space-y-6 text-cantaloupe-soft-deep/80 text-lg leading-relaxed">
                <p>
                  At The Growth Arc Counselling, we believe personal growth rarely follows a straight path. Life brings challenges, uncertainty, and emotional struggles that can feel overwhelming when faced alone.
                </p>
                <p>
                  Our practice provides confidential online counselling for individuals, couples, and professionals across India who are seeking clarity, emotional support, and personal growth.
                </p>
                <p>
                  We believe that meaningful change happens when people feel safe enough to explore their thoughts and emotions without judgment.
                </p>
              </div>
              <div className="mt-12 grid grid-cols-2 gap-6">
                {['Self-awareness', 'Emotional resilience', 'Healthy communication', 'Personal growth'].map((item, i) => (
                  <div key={i} className="flex items-center gap-3 text-cantaloupe-soft-deep font-medium">
                    <div className="w-2 h-2 bg-cantaloupe-solid rounded-full" />
                    {item}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* Values */}
        <section className="section-padding bg-saffron-soft">
          <div className="max-w-7xl mx-auto">
            <h2 className="text-4xl font-serif font-bold text-cantaloupe-deep mb-16 text-center">Our Core Values</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
              {[
                {
                  title: 'Safety First',
                  desc: 'Every conversation is held within strict confidentiality.',
                  icon: <Shield className="text-cantaloupe-solid" />
                },
                {
                  title: 'Human Connection',
                  desc: 'We prioritize warmth, empathy, and genuine understanding.',
                  icon: <Heart className="text-cantaloupe-solid" />
                },
                {
                  title: 'Ethical Integrity',
                  desc: 'We operate within clear professional boundaries and responsible counselling practices.',
                  icon: <Scale className="text-cantaloupe-solid" />
                }
              ].map((value, i) => (
                <div key={i} className="arc-card text-center bg-cantaloupe-whisper/50">
                  <div className="w-16 h-16 bg-white rounded-2xl shadow-sm flex items-center justify-center mx-auto mb-8 text-cantaloupe-solid border border-glass-border">
                    {value.icon}
                  </div>
                  <h3 className="text-2xl font-serif font-bold text-cantaloupe-deep mb-4">{value.title}</h3>
                  <p className="text-cantaloupe-soft-deep/60 leading-relaxed">{value.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Founder Note */}
        <section className="py-12 px-6 bg-cantaloupe-whisper">
          <div className="max-w-5xl mx-auto bg-cantaloupe-deep rounded-[60px] p-8 md:p-12 text-white relative overflow-hidden">
            <div className="absolute top-0 right-0 w-64 h-64 bg-white/5 rounded-full blur-3xl" />
            <div className="relative z-10">
              <span className="text-white/60 uppercase tracking-widest text-sm font-bold mb-4 block">Founder's Note</span>
              <h2 className="text-4xl md:text-5xl font-serif font-bold mb-8">A Growth Arc Counselling Perspective</h2>
              <div className="space-y-6 text-white/80 text-lg leading-relaxed font-light">
                <p>
                  The Growth Arc Counselling didn’t begin in an office; it began with a conversation between three colleagues about the complexities of the modern workplace and the human psyche. We found ourselves asking: How do we move beyond just "getting by" to truly thriving?
                </p>
                <p>
                  As a student of Freudian thought, I have always been fascinated by the "hidden" drivers of our behavior—the internal maps that dictate our external success. It was during our 60 hours of intensive clinical postings that this fascination turned into a mission.
                </p>
                <p className="text-white font-serif italic text-2xl border-l-4 border-cantaloupe-solid pl-8 my-8">
                  "We created The Growth Arc Counselling to be a bridge between where you are and where you want to be. Our philosophy is simple: we look beneath the surface to understand the roots, so you can reach for the heights."
                </p>
                <p>
                  We don't just help you move past the obstacles. We heal, and we grow. ✨
                </p>
              </div>
              <div className="mt-12 flex items-center gap-6">
                <div className="w-20 h-20 rounded-full overflow-hidden border-2 border-cantaloupe-solid">
                  <img
                    src="https://drive.google.com/thumbnail?id=1rlhdjjDxOC1qz82rF469wQt9iwFqeAZS&sz=w1000" // Gadadhar
                    alt="Gadadhar"
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                </div>
                <div>
                  <h4 className="text-xl font-bold">Gadadhar</h4>
                  <p className="text-white/60 text-sm">Founder, The Growth Arc Counselling</p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Boundaries */}
        <section className="section-padding bg-saffron-soft">
          <div className="max-w-4xl mx-auto">
            <div className="bg-cantaloupe-whisper rounded-3xl p-12 border border-glass-border">
              <h2 className="text-3xl font-serif font-bold text-cantaloupe-deep mb-8">Professional Boundaries</h2>
              <p className="text-cantaloupe-soft-deep/80 mb-8 leading-relaxed">
                Our practice provides non-clinical counselling services only. We are committed to ethical practice and ensuring you receive the appropriate level of care.
              </p>
              <div className="bg-red-50 border-l-4 border-red-200 p-6 rounded-r-xl mb-8">
                <h4 className="text-red-800 font-bold mb-2">We do not provide:</h4>
                <ul className="grid grid-cols-1 md:grid-cols-3 gap-4 text-red-700 text-sm">
                  <li className="flex items-center gap-2">• Psychiatric care</li>
                  <li className="flex items-center gap-2">• Medical advice</li>
                  <li className="flex items-center gap-2">• Emergency crisis services</li>
                </ul>
              </div>
              <p className="text-cantaloupe-soft-deep/60 text-sm italic">
                Individuals requiring clinical or emergency support should contact appropriate medical professionals or emergency services immediately.
              </p>
            </div>
          </div>
        </section>
      </div>
    </PageTransition>
  );
}
