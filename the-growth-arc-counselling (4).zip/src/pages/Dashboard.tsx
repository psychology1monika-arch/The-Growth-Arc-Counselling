import { motion, AnimatePresence } from 'motion/react';
import { useState, useEffect } from 'react';
import { Calendar, Clock, Video, FileText, CheckCircle, ArrowRight, Sparkles, Wind, ChevronRight, Zap } from 'lucide-react';
import PageTransition from '../components/PageTransition';
import { useMood } from '../contexts/MoodContext';

const ResourceItem = ({ title, status, icon: Icon }: { title: string, status: string, icon: any }) => {
  const { currentMood } = useMood();
  return (
    <div className="flex items-center justify-between p-6 bg-saffron-soft/50 backdrop-blur-md rounded-[32px] border border-glass-border hover:bg-saffron-soft transition-all group cursor-pointer">
      <div className="flex items-center gap-5">
        <div className="w-12 h-12 rounded-2xl bg-cantaloupe-solid/10 flex items-center justify-center text-cantaloupe-soft-deep/60 group-hover:scale-110 transition-transform">
          <Icon size={22} />
        </div>
        <div>
          <h4 className="text-base font-serif font-bold text-cantaloupe-deep tracking-tight">{title}</h4>
          <p className="text-[10px] uppercase tracking-[0.2em] text-cantaloupe-soft-deep/40 mt-1">{status}</p>
        </div>
      </div>
      <div className="w-8 h-8 rounded-full bg-cantaloupe-solid/10 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all group-hover:translate-x-1">
        <ChevronRight size={16} className="text-cantaloupe-deep" />
      </div>
    </div>
  );
};

export default function Dashboard() {
  const { currentMood } = useMood();
  const [timeLeft, setTimeLeft] = useState(3600); // 1 hour in seconds for demo
  const [isJoinEnabled, setIsJoinEnabled] = useState(false);
  const [isBreathing, setIsBreathing] = useState(false);

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => (prev > 0 ? prev - 1 : 0));
    }, 1000);

    // Enable join button if less than 5 minutes (300 seconds) left
    if (timeLeft <= 300) {
      setIsJoinEnabled(true);
    }

    return () => clearInterval(timer);
  }, [timeLeft]);

  const formatTime = (seconds: number) => {
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = seconds % 60;
    return `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  return (
    <PageTransition>
      <div className="min-h-screen bg-cantaloupe-whisper pt-32 pb-40 px-6 relative overflow-hidden">
        {/* Subtle Mood Glow */}
        <div 
          className="absolute top-0 right-0 w-[800px] h-[800px] blur-[150px] rounded-full opacity-10 pointer-events-none transition-all duration-1000"
          style={{ background: `radial-gradient(circle, ${currentMood.color} 0%, transparent 70%)` }}
        />
        
        <div className="max-w-6xl mx-auto relative z-10">
          <header className="mb-16">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="flex flex-col md:flex-row md:items-end justify-between gap-8"
            >
              <div>
                <h1 className="text-5xl md:text-7xl font-serif font-bold text-cantaloupe-deep tracking-tighter mb-4">
                  Welcome back, <span className="italic text-cantaloupe-soft-deep/40">Friend.</span>
                </h1>
                <p className="text-cantaloupe-soft-deep/60 text-xl font-light tracking-wide max-w-xl">
                  Your sanctuary is ready. Take a breath, center your thoughts, and prepare for your journey inward.
                </p>
              </div>
              <div className="flex items-center gap-4 px-6 py-3 bg-saffron-soft backdrop-blur-2xl rounded-full border border-glass-border">
                <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse shadow-[0_0_10px_rgba(34,197,94,0.5)]" />
                <span className="text-[10px] font-bold uppercase tracking-[0.3em] text-cantaloupe-soft-deep/60">Sanctuary Online</span>
              </div>
            </motion.div>
          </header>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
            {/* Main Session Card */}
            <div className="lg:col-span-8 space-y-10">
              <motion.div
                initial={{ opacity: 0, scale: 0.98 }}
                animate={{ opacity: 1, scale: 1 }}
                className="p-12 bg-saffron-soft/50 backdrop-blur-3xl rounded-[64px] border border-glass-border shadow-2xl relative overflow-hidden group"
              >
                <div className="absolute top-0 right-0 p-12 opacity-5 group-hover:opacity-10 transition-opacity duration-1000">
                  <Sparkles size={160} className="text-cantaloupe-deep" />
                </div>

                <div className="relative z-10">
                  <div className="flex items-center gap-4 mb-10">
                    <div 
                      className="px-4 py-1.5 rounded-full text-[10px] font-bold uppercase tracking-[0.3em] text-white"
                      style={{ backgroundColor: currentMood.color }}
                    >
                      Upcoming Session
                    </div>
                    <span className="text-cantaloupe-soft-deep/40 text-xs font-bold uppercase tracking-widest">with Gadadhar</span>
                  </div>

                  <div className="mb-16">
                    <h2 className="text-8xl md:text-9xl font-mono font-light text-cantaloupe-deep tracking-tighter mb-6">
                      {formatTime(timeLeft)}
                    </h2>
                    <p className="text-cantaloupe-soft-deep/20 text-sm font-bold uppercase tracking-[0.5em]">Ticking towards clarity</p>
                  </div>

                  <div className="flex flex-col sm:flex-row gap-6">
                    <button
                      disabled={!isJoinEnabled}
                      className={`flex-1 flex items-center justify-center gap-4 py-6 rounded-[32px] font-bold text-sm uppercase tracking-[0.2em] transition-all ${
                        isJoinEnabled 
                        ? 'bg-cantaloupe-solid text-white hover:scale-[1.02] active:scale-95 shadow-2xl shadow-cantaloupe-solid/10' 
                        : 'bg-saffron-soft/50 text-cantaloupe-soft-deep/20 cursor-not-allowed border border-glass-border'
                      }`}
                    >
                      <Video size={20} />
                      Join Session
                    </button>
                    <button className="px-10 py-6 bg-transparent border border-glass-border text-cantaloupe-soft-deep/60 rounded-[32px] font-bold text-sm uppercase tracking-[0.2em] hover:bg-saffron-soft/50 hover:text-cantaloupe-deep transition-all">
                      Reschedule
                    </button>
                  </div>
                </div>
              </motion.div>

              {/* Pre-Session Ritual */}
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
                className="p-12 bg-saffron-soft/50 backdrop-blur-xl rounded-[64px] border border-glass-border shadow-2xl relative overflow-hidden group"
              >
                <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-12">
                  <div className="max-w-md">
                    <h3 className="text-3xl font-serif font-bold text-cantaloupe-deep mb-4 italic">The Pre-Session Ritual</h3>
                    <p className="text-cantaloupe-soft-deep/40 text-lg leading-relaxed font-light">
                      Take a moment to center yourself. Follow the circle to sync your breath before we begin. This small act of presence prepares the ground for healing.
                    </p>
                    <button 
                      onClick={() => setIsBreathing(!isBreathing)}
                      className="mt-8 flex items-center gap-3 text-xs font-bold uppercase tracking-[0.3em] text-cantaloupe-soft-deep/60 hover:text-cantaloupe-deep transition-all group/btn"
                    >
                      <div className="w-10 h-10 rounded-full border border-glass-border flex items-center justify-center group-hover/btn:border-cantaloupe-solid/30 transition-all">
                        <Wind size={18} className={isBreathing ? 'animate-pulse' : ''} />
                      </div>
                      {isBreathing ? 'Stop Ritual' : 'Start Breathing'}
                    </button>
                  </div>

                  <div className="relative w-64 h-64 flex items-center justify-center">
                    <AnimatePresence>
                      {isBreathing && (
                        <>
                          <motion.div
                            initial={{ scale: 0.8, opacity: 0 }}
                            animate={{ 
                              scale: [0.8, 1.6, 0.8],
                              opacity: [0.2, 0.5, 0.2]
                            }}
                            transition={{ 
                              duration: 8, 
                              repeat: Infinity, 
                              ease: "easeInOut" 
                            }}
                            className="absolute inset-0 rounded-full blur-3xl"
                            style={{ backgroundColor: currentMood.color }}
                          />
                          <motion.div
                            initial={{ scale: 0.5, opacity: 0 }}
                            animate={{ 
                              scale: [0.5, 1.3, 0.5],
                              opacity: [0.4, 1, 0.4]
                            }}
                            transition={{ 
                              duration: 8, 
                              repeat: Infinity, 
                              ease: "easeInOut" 
                            }}
                            className="w-32 h-32 border-2 border-glass-border rounded-full flex items-center justify-center"
                          >
                            <motion.span
                              animate={{ 
                                opacity: [0, 1, 0],
                              }}
                              transition={{ 
                                duration: 8, 
                                repeat: Infinity, 
                                ease: "easeInOut" 
                              }}
                              className="text-[10px] font-bold uppercase tracking-[0.4em] text-cantaloupe-deep"
                            >
                              {timeLeft % 16 < 8 ? 'Inhale' : 'Exhale'}
                            </motion.span>
                          </motion.div>
                        </>
                      )}
                    </AnimatePresence>
                    {!isBreathing && (
                      <div className="w-32 h-32 border-2 border-glass-border/10 rounded-full flex items-center justify-center">
                        <Wind size={32} className="text-cantaloupe-deep/10" />
                      </div>
                    )}
                  </div>
                </div>
              </motion.div>
            </div>

            {/* Sidebar: Resources & Info */}
            <div className="lg:col-span-4 space-y-10">
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.3 }}
                className="p-10 bg-saffron-soft/50 backdrop-blur-2xl rounded-[56px] border border-glass-border shadow-xl"
              >
                <h3 className="text-xl font-serif font-bold text-cantaloupe-deep mb-8 flex items-center gap-3">
                  <FileText size={24} className="text-cantaloupe-deep/20" />
                  Resource Vault
                </h3>
                <div className="space-y-5">
                  <ResourceItem title="Informed Consent" status="Signed & Verified" icon={CheckCircle} />
                  <ResourceItem title="Intake Form" status="Pending Review" icon={Clock} />
                  <ResourceItem title="Journaling Prompt #1" status="New Resource" icon={Sparkles} />
                </div>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.4 }}
                className="p-10 bg-saffron-soft/50 rounded-[56px] border border-glass-border"
              >
                <h3 className="text-[10px] font-bold text-cantaloupe-soft-deep/40 uppercase tracking-[0.4em] mb-8">Session Details</h3>
                <div className="space-y-6">
                  <div className="flex items-center gap-4 text-cantaloupe-soft-deep/60">
                    <div className="w-10 h-10 rounded-2xl bg-cantaloupe-solid/10 flex items-center justify-center">
                      <Calendar size={18} />
                    </div>
                    <span className="text-sm font-medium">Tuesday, March 17, 2026</span>
                  </div>
                  <div className="flex items-center gap-4 text-cantaloupe-soft-deep/60">
                    <div className="w-10 h-10 rounded-2xl bg-cantaloupe-solid/10 flex items-center justify-center">
                      <Clock size={18} />
                    </div>
                    <span className="text-sm font-medium">05:00 PM - 06:00 PM</span>
                  </div>
                  <div className="pt-8 border-t border-glass-border">
                    <p className="text-[10px] text-cantaloupe-soft-deep/30 leading-relaxed uppercase tracking-widest font-bold">
                      Need immediate support? Our crisis lines are available 24/7 in the footer.
                    </p>
                  </div>
                </div>
              </motion.div>

              {/* Quick Action */}
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="w-full p-8 bg-cantaloupe-solid text-white rounded-[48px] font-bold text-sm uppercase tracking-[0.3em] flex items-center justify-center gap-4 shadow-2xl"
                style={{ backgroundColor: currentMood.color, color: 'white' }}
              >
                <Zap size={20} />
                New Booking
              </motion.button>
            </div>
          </div>
        </div>
      </div>
    </PageTransition>
  );
}
