import PageTransition from '../components/PageTransition';

export default function Policies() {
  return (
    <PageTransition>
      <div className="pt-20 pb-12 px-6">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-5xl md:text-7xl font-serif font-bold text-cantaloupe-deep mb-10">Policies</h1>

          <div className="space-y-12">
            <section>
              <h2 className="text-3xl font-serif font-bold text-cantaloupe-deep mb-6">Privacy Policy</h2>
              <div className="markdown-body">
                <p>At The Growth Arc Counselling, we are committed to protecting your privacy. This policy outlines how we collect, use, and safeguard your personal information.</p>
                <ul>
                  <li>We collect personal data only to provide and improve our counselling services.</li>
                  <li>Your data is stored securely and is never shared with third parties without your explicit consent, except as required by law.</li>
                  <li>We use encrypted platforms for all virtual sessions to ensure your privacy.</li>
                </ul>
              </div>
            </section>

            <section>
              <h2 className="text-3xl font-serif font-bold text-cantaloupe-deep mb-6">Terms of Service</h2>
              <div className="markdown-body">
                <p>By using our services, you agree to the following terms:</p>
                <ul>
                  <li>Our services are for non-clinical counselling and personal development guidance only.</li>
                  <li>We do not provide emergency crisis intervention or medical advice.</li>
                  <li>Clients are responsible for providing accurate information during the intake process.</li>
                </ul>
              </div>
            </section>

            <section>
              <h2 className="text-3xl font-serif font-bold text-cantaloupe-deep mb-6">Cancellation Policy</h2>
              <div className="markdown-body">
                <p>We value your time and our counsellors' time. Our cancellation policy is as follows:</p>
                <ul>
                  <li>There is no cancellation or return of fee once the booking is confirmed.</li>
                  <li>Rescheduling should be requested at least 2-4 hours before the scheduled session.</li>
                  <li>No-shows will be charged the full session fee.</li>
                </ul>
              </div>
            </section>

            <section>
              <h2 className="text-3xl font-serif font-bold text-cantaloupe-deep mb-6">Confidentiality Policy</h2>
              <div className="markdown-body">
                <p>Confidentiality is the cornerstone of the therapeutic relationship. Everything discussed in your sessions is confidential, with the following legal exceptions:</p>
                <ul>
                  <li>If there is a risk of serious harm to yourself or others.</li>
                  <li>If there is a legal requirement to disclose information (e.g., a court order).</li>
                  <li>In cases of suspected abuse of children or vulnerable adults.</li>
                </ul>
              </div>
            </section>

            <section>
              <h2 className="text-3xl font-serif font-bold text-cantaloupe-deep mb-6">Informed Consent</h2>
              <div className="markdown-body">
                <p>Before beginning counselling, you will be asked to sign an Informed Consent form. This document ensures you understand the nature of our services, the risks and benefits of counselling, and your rights as a client.</p>
              </div>
            </section>
          </div>
        </div>
      </div>
    </PageTransition>
  );
}
