import { motion } from 'motion/react';
import PageTransition from '../components/PageTransition';

export default function Founder() {
  return (
    <PageTransition>
      <div className="pt-20 pb-12 px-6">
        <div className="max-w-4xl mx-auto">
          <div className="mb-10 text-center">
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              className="w-32 h-32 rounded-full overflow-hidden border-4 border-cantaloupe-solid/20 mx-auto mb-8 shadow-xl"
            >
              <img
                src="https://drive.google.com/thumbnail?id=1rlhdjjDxOC1qz82rF469wQt9iwFqeAZS&sz=w1000" // Gadadhar
                alt="Gadadhar"
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </motion.div>
            <h1 className="text-5xl md:text-7xl font-serif font-bold text-cantaloupe-deep mb-4">The Founder’s Note</h1>
            <p className="text-cantaloupe-solid font-bold uppercase tracking-widest">A Growth Arc Counselling Perspective</p>
          </div>

          <div className="bg-saffron-soft/50 backdrop-blur-sm rounded-[60px] p-10 md:p-20 shadow-sm border border-glass-border relative overflow-hidden">
            {/* Decorative Doodle-like element */}
            <div className="absolute -top-10 -right-10 w-40 h-40 bg-cantaloupe-solid/5 rounded-full blur-2xl" />
            <div className="absolute -bottom-10 -left-10 w-40 h-40 bg-saffron-solid/5 rounded-full blur-2xl" />

            <div className="relative z-10 space-y-8 text-cantaloupe-soft-deep/80 text-lg md:text-xl leading-relaxed font-serif italic">
              <p className="font-bold text-cantaloupe-deep not-italic mb-12 text-2xl">From a Conversation to a Calling</p>
              
              <p>
                The Growth Arc Counselling didn’t begin in an office; it began with a conversation between three colleagues about the complexities of the modern workplace and the human psyche. We found ourselves asking: How do we move beyond just "getting by" to truly thriving?
              </p>
              
              <p>
                As a student of Freudian thought, I have always been fascinated by the "hidden" drivers of our behavior—the internal maps that dictate our external success. It was during our 60 hours of intensive clinical postings that this fascination turned into a mission.
              </p>
              
              <p>
                Witnessing firsthand the profound shift that occurs when a person feels truly heard, we realized we couldn't just work for a firm; we had to build one.
              </p>

              <div className="py-8 border-y border-glass-border/50 my-8">
                <p className="text-3xl md:text-4xl text-cantaloupe-deep leading-tight">
                  "We created The Growth Arc Counselling to be a bridge between where you are and where you want to be. Our philosophy is simple: we look beneath the surface to understand the roots, so you can reach for the heights."
                </p>
              </div>

              <p>
                We don't just help you move past the obstacles. We heal, and we grow. ✨
              </p>

              <div className="pt-8">
                <p className="font-bold text-cantaloupe-deep not-italic">— Gadadhar</p>
                <p className="text-cantaloupe-solid text-sm not-italic uppercase tracking-widest font-bold">Founder, The Growth Arc Counselling</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </PageTransition>
  );
}
