import { motion } from 'motion/react';
import { Heart, Users, Briefcase, Sparkles, ArrowRight, CheckCircle2 } from 'lucide-react';
import PageTransition from '../components/PageTransition';

const counsellingServices = [
  {
    title: 'Individual Counselling',
    icon: <Sparkles />,
    items: ['Anxiety', 'Overthinking', 'Identity confusion', 'Stress', 'Self-esteem']
  },
  {
    title: 'Couples Counselling',
    icon: <Heart />,
    items: ['Communication issues', 'Conflict resolution', 'Emotional disconnect', 'Premarital counselling']
  },
  {
    title: 'Professional Wellbeing',
    icon: <Briefcase />,
    items: ['Burnout', 'Work stress', 'Career confusion', 'Work-life balance']
  }
];

const workshopTopics = [
  {
    title: 'Workplace Wellbeing',
    audience: 'Teams & Organizations',
    topics: [
      'Emotional Intelligence at Work',
      'Stress Management & Burnout Prevention',
      'Effective Communication & Active Listening',
      'Growth Mindset and Resilience Building',
      'Conflict Resolution & Healthy Workplace Relationships'
    ]
  },
  {
    title: 'Student Success',
    audience: 'Schools & Colleges',
    topics: [
      'Exam Anxiety Management',
      'Study Skills & Focus',
      'College Adjustment',
      'Emotional Regulation for Students'
    ]
  }
];

export default function Services() {
  return (
    <PageTransition>
      <div className="pt-32 pb-20">
        {/* Header */}
        <section className="px-6 mb-20 text-center">
          <div className="max-w-3xl mx-auto">
            <h1 className="text-5xl md:text-7xl font-serif font-bold text-stone-900 mb-6">Our Services</h1>
            <p className="text-xl text-stone-600 leading-relaxed">
              Tailored support for individuals, couples, and organizations seeking meaningful change.
            </p>
          </div>
        </section>

        {/* Counselling */}
        <section className="section-padding bg-white">
          <div className="max-w-7xl mx-auto">
            <div className="flex items-center gap-4 mb-16">
              <div className="h-px flex-1 bg-stone-200" />
              <h2 className="text-3xl font-serif font-bold text-stone-800 px-6">Counselling</h2>
              <div className="h-px flex-1 bg-stone-200" />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
              {counsellingServices.map((service, i) => (
                <motion.div
                  key={i}
                  whileInView={{ opacity: 1, y: 0 }}
                  initial={{ opacity: 0, y: 20 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 }}
                  className="arc-card group"
                >
                  <div className="w-16 h-16 bg-sage-50 rounded-2xl flex items-center justify-center text-sage-600 mb-8 group-hover:bg-sage-600 group-hover:text-white transition-all duration-500">
                    {service.icon}
                  </div>
                  <h3 className="text-2xl font-serif font-bold text-stone-900 mb-6">{service.title}</h3>
                  <ul className="space-y-4">
                    {service.items.map((item, j) => (
                      <li key={j} className="flex items-center gap-3 text-stone-600">
                        <CheckCircle2 size={16} className="text-sage-500" />
                        {item}
                      </li>
                    ))}
                  </ul>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Workshops */}
        <section className="section-padding bg-stone-50">
          <div className="max-w-7xl mx-auto">
            <div className="flex items-center gap-4 mb-16">
              <div className="h-px flex-1 bg-stone-200" />
              <h2 className="text-3xl font-serif font-bold text-stone-800 px-6">Workshops</h2>
              <div className="h-px flex-1 bg-stone-200" />
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
              {workshopTopics.map((workshop, i) => (
                <motion.div
                  key={i}
                  whileInView={{ opacity: 1, x: 0 }}
                  initial={{ opacity: 0, x: i === 0 ? -20 : 20 }}
                  viewport={{ once: true }}
                  className="bg-white rounded-[40px] p-12 border border-stone-200 shadow-sm overflow-hidden relative"
                >
                  <div className="absolute top-0 right-0 w-32 h-32 bg-sage-50 rounded-bl-[100px] -z-0" />
                  <div className="relative z-10">
                    <span className="text-sage-600 font-bold text-xs uppercase tracking-widest mb-4 block">
                      Workshops for {workshop.audience}
                    </span>
                    <h3 className="text-3xl font-serif font-bold text-stone-900 mb-8">{workshop.title}</h3>
                    <div className="space-y-4">
                      {workshop.topics.map((topic, j) => (
                        <div key={j} className="flex items-start gap-4 p-4 rounded-2xl hover:bg-stone-50 transition-colors">
                          <div className="w-6 h-6 bg-sage-100 rounded-full flex items-center justify-center text-sage-600 shrink-0 mt-1">
                            <ArrowRight size={14} />
                          </div>
                          <p className="text-stone-700 font-medium">{topic}</p>
                        </div>
                      ))}
                    </div>
                    <button className="mt-12 btn-primary w-full">Inquire About Workshops</button>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA */}
        <section className="section-padding bg-white text-center">
          <div className="max-w-3xl mx-auto">
            <h2 className="text-4xl font-serif font-bold text-stone-900 mb-8">Not sure which service is right for you?</h2>
            <p className="text-stone-600 mb-12 text-lg">
              We offer a brief consultation to help you understand our approach and how we can support your specific needs.
            </p>
            <button className="btn-secondary">Contact Us for Guidance</button>
          </div>
        </section>
      </div>
    </PageTransition>
  );
}
