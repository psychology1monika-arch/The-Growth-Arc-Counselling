import { motion, useScroll, useTransform } from 'motion/react';
import { Link } from 'react-router-dom';
import { Sparkles, Book, Palette, Coffee, Heart, Zap, Brain } from 'lucide-react';
import PageTransition from '../components/PageTransition';
import { DoodlePlant, DoodleHeart, DoodleBrain, DoodleSparkle, DoodleArc } from '../components/Doodles';
import { useMood } from '../contexts/MoodContext';

const team = [
  {
    name: 'Gadadhar',
    role: 'Founder & Counselling Psychologist',
    bio: 'Gadadhar brings a deep academic perspective to his practice, focusing on the intersection of psychology and philosophy.',
    tags: ['Social Anxiety', 'Freudian-ish', 'Night Owl', 'Existentialism', 'Vinyl Collector'],
    languages: ['EN', 'TA'],
    img: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=400&fm=webp',
    humanBit: 'Gadadhar is an avid reader of existential philosophy and can often be found in local libraries with a stack of old books.',
    doodle: DoodleArc,
    aura: 'from-clay-muted/40 to-transparent'
  },
  {
    name: 'Haritaa. L.G',
    role: 'Counselling Psychologist',
    bio: 'Haritaa is a dedicated psychologist with a passion for helping individuals navigate their emotional landscapes.',
    tags: ['Anxiety', 'Relationships', 'Self-Growth', 'Morning Person', 'Tea Enthusiast'],
    languages: ['EN', 'TA'],
    img: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=400&fm=webp',
    humanBit: 'When not in session, Haritaa finds peace in creating intricate mandalas and exploring the quiet corners of Chennai.',
    doodle: DoodleSparkle,
    aura: 'from-sage-ethereal/40 to-transparent'
  },
  {
    name: 'Monika. V',
    role: 'Counselling Psychologist',
    bio: 'Monika specializes in supporting young adults through life transitions and career challenges.',
    tags: ['Career Stress', 'Life Transitions', 'Empathetic', 'Rescue Pets', 'Coffee Nerd'],
    languages: ['EN', 'TA'],
    img: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?auto=format&fit=crop&q=80&w=400&fm=webp',
    humanBit: 'Monika is a coffee enthusiast who loves discovering new blends and spending time with her rescue pets.',
    doodle: DoodleHeart,
    aura: 'from-sage-ethereal/40 to-transparent'
  },
];

const AuraCard = ({ member, index }: { member: any, index: number }) => {
  const { currentMood } = useMood();
  
  return (
    <motion.div
      initial={{ opacity: 0, y: 50 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-100px" }}
      className={`flex flex-col ${index % 2 === 1 ? 'md:flex-row-reverse' : 'md:flex-row'} gap-12 md:gap-24 items-center py-32`}
    >
      {/* Digital Altar / Aura Card */}
      <div className="flex-1 w-full relative group">
        <motion.div 
          className="relative z-10 aspect-[4/5] overflow-hidden rounded-[60px] md:rounded-[100px] shadow-2xl border border-off-white/10"
          whileHover={{ scale: 1.02 }}
        >
          <img 
            src={member.img} 
            alt={member.name} 
            className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-1000 group-hover:scale-105"
            referrerPolicy="no-referrer"
          />
          
          {/* Moving Aura Blob Mask */}
          <motion.div 
            animate={{ 
              scale: [1, 1.2, 1],
              rotate: [0, 90, 180, 270, 360],
              borderRadius: ["40% 60% 70% 30% / 40% 50% 60% 50%", "60% 40% 30% 70% / 50% 60% 40% 60%", "40% 60% 70% 30% / 40% 50% 60% 50%"]
            }}
            transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
            className="absolute inset-0 mix-blend-overlay opacity-0 group-hover:opacity-100 transition-opacity duration-1000"
            style={{ background: `linear-gradient(to bottom right, ${currentMood.color}66, transparent)` }}
          />
        </motion.div>
        
        {/* Floating Doodle Reveal */}
        <div className="absolute -top-12 -right-12 z-20 w-32 h-32 pointer-events-none">
          <member.doodle className="w-full h-full opacity-0 group-hover:opacity-100 group-hover:scale-110 transition-all duration-700" style={{ color: currentMood.color }} />
        </div>

        {/* Aura Background Glow */}
        <div 
          className="absolute inset-0 blur-[120px] rounded-full -z-10 opacity-20 group-hover:opacity-40 transition-opacity duration-1000" 
          style={{ background: `radial-gradient(circle, ${currentMood.color}66 0%, transparent 70%)` }}
        />
      </div>

      {/* Content */}
      <div className="flex-1 space-y-8">
        <div className="space-y-4">
          <div className="flex flex-wrap items-center gap-4">
            <h2 className="text-5xl md:text-7xl font-serif font-bold text-off-white tracking-tight">{member.name}</h2>
            <div className="flex gap-2">
              {member.languages.map(lang => (
                <span key={lang} className="px-3 py-1 bg-off-white/5 text-off-white/40 text-[10px] font-bold rounded-full border border-off-white/10 uppercase tracking-widest">
                  {lang}
                </span>
              ))}
            </div>
          </div>
          <p className="font-bold text-lg uppercase tracking-[0.3em]" style={{ color: currentMood.color }}>{member.role}</p>
          
          <div className="flex flex-wrap gap-2">
            {member.tags.map(tag => (
              <span 
                key={tag} 
                className="px-4 py-2 bg-off-white/5 rounded-full text-xs font-bold text-off-white/60 border border-off-white/10 transition-all cursor-default hover:text-off-white"
                style={{ borderColor: 'rgba(255,255,255,0.1)' }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.borderColor = currentMood.color;
                  e.currentTarget.style.backgroundColor = `${currentMood.color}11`;
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.borderColor = 'rgba(255,255,255,0.1)';
                  e.currentTarget.style.backgroundColor = 'rgba(255,255,255,0.05)';
                }}
              >
                {tag}
              </span>
            ))}
          </div>

          <p className="text-off-white/80 text-2xl font-serif italic leading-relaxed pt-4">
            "{member.bio}"
          </p>
        </div>

        {/* The Human Bit */}
        <div className="p-8 bg-off-white/5 backdrop-blur-xl rounded-[40px] border border-off-white/10 relative overflow-hidden group/bit">
          <div className="absolute top-0 right-0 p-6 opacity-5 group-hover/bit:opacity-10 transition-opacity">
            <Sparkles size={48} style={{ color: currentMood.color }} />
          </div>
          <h4 className="text-[10px] font-bold uppercase tracking-[0.4em] text-clay-muted mb-4">The Human Bit</h4>
          <p className="text-off-white/60 text-lg leading-relaxed">
            {member.humanBit}
          </p>
        </div>

      </div>
    </motion.div>
  );
};

export default function Team() {
  const { currentMood } = useMood();

  return (
    <PageTransition>
      <div className="min-h-screen bg-moss-black pt-32 pb-40 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="text-center max-w-3xl mx-auto mb-32">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
            >
              <h1 className="text-6xl md:text-8xl font-serif font-bold text-off-white mb-8 tracking-tighter">
                The <span className="italic transition-colors duration-1000" style={{ color: currentMood.color }}>Human</span> Connection
              </h1>
              <p className="text-off-white/40 text-xl leading-relaxed">
                Meet the people behind the arc. We believe that therapy is first and foremost 
                a human relationship built on trust, empathy, and shared understanding.
              </p>
            </motion.div>
          </div>

          <div className="space-y-12">
            {team.map((member, i) => (
              <AuraCard key={i} member={member} index={i} />
            ))}
          </div>

          {/* Bottom CTA */}
          <div className="mt-40 text-center">
            <h3 className="text-3xl md:text-5xl font-serif font-bold text-off-white mb-12">
              Ready to find your <span className="italic transition-colors duration-1000" style={{ color: currentMood.color }}>match</span>?
            </h3>
            <Link 
              to="/booking" 
              className="inline-flex items-center gap-3 px-10 py-5 text-white rounded-full font-bold text-lg hover:opacity-90 transition-all shadow-2xl"
              style={{ backgroundColor: currentMood.color, boxShadow: `0 20px 40px ${currentMood.color}33` }}
            >
              Book a Session
              <Zap size={20} />
            </Link>
          </div>
        </div>
      </div>
    </PageTransition>
  );
}
