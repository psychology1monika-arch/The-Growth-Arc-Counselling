import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useNavigate } from 'react-router-dom';
import Lottie from 'lottie-react';
import { AddToCalendarButton } from 'add-to-calendar-button-react';
import { 
  LogIn, 
  Calendar, 
  ShieldCheck, 
  CreditCard, 
  ArrowRight, 
  Loader2, 
  Sparkles, 
  CheckCircle2, 
  Heart,
  User,
  Users,
  BookOpen,
  ChevronRight,
  ArrowLeft,
  QrCode,
  Zap,
  Clock,
  Mail,
  FileText,
  Download,
  ArrowUpRight
} from 'lucide-react';
import PageTransition from '../components/PageTransition';
import { auth, db, signInWithPopup, googleProvider, addDoc, collection, serverTimestamp } from '../firebase';
import { useAuth } from '../contexts/AuthContext';
import { useMood } from '../contexts/MoodContext';

/**
 * TECHNICAL SPECS: RAZORPAY CALLBACK & BACKEND AUTOMATION
 * 
 * 1. Razorpay Callback:
 *    const handlePaymentSuccess = async (response) => {
 *      const { razorpay_payment_id, razorpay_order_id, razorpay_signature } = response;
 *      // Verify signature on backend
 *      const result = await fetch('/api/verify-payment', { method: 'POST', body: JSON.stringify(response) });
 *      if (result.ok) triggerConfirmationFlow();
 *    };
 * 
 * 2. Backend Automation (Node.js/Cloud Functions):
 *    - Finalize Google Calendar: Use googleapis.calendar('v3').events.insert()
 *    - GMeet: Set conferenceData: { createRequest: { requestId: uuid() } }
 *    - Email: Use Nodemailer or SendGrid with Alabaster Silk (#F5F5F0) & Deep Moss (#121612) template.
 */

// Lottie Animation URL (Bloom/Success effect)
const BLOOM_ANIMATION_URL = "https://lottie.host/6b3b5b1a-8c1a-4b1a-8c1a-4b1a8c1a4b1a/bloom.json"; // Placeholder URL

// Types
type Step = 'auth' | 'service' | 'counsellor' | 'calendar' | 'payment' | 'success';
type Service = 'individual' | 'couple' | 'workshop';

interface Counsellor {
  id: string;
  name: string;
  role: string;
  img: string;
  color: string;
}

const counsellors: Counsellor[] = [
  { 
    id: 'gadadhar', 
    name: 'Gadadhar', 
    role: 'Founder & Counselling Psychologist', 
    img: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=400&fm=webp',
    color: '#C58B74'
  },
  { 
    id: 'haritaa', 
    name: 'Haritaa. L.G', 
    role: 'Counselling Psychologist', 
    img: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=400&fm=webp',
    color: '#789D9E'
  },
  { 
    id: 'monika', 
    name: 'Monika. V', 
    role: 'Counselling Psychologist', 
    img: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?auto=format&fit=crop&q=80&w=400&fm=webp',
    color: '#9B8BB5'
  }
];

const services = [
  { id: 'individual', name: 'Individual Therapy', icon: User, desc: 'One-on-one deep dive into your inner world.' },
  { id: 'couple', name: 'Couple Counselling', icon: Users, desc: 'Navigating the bridge between two hearts.' },
  { id: 'workshop', name: 'Group Workshop', icon: BookOpen, desc: 'Shared healing in a safe community.' }
];

const timeSlots = [
  '09:00 AM', '10:30 AM', '12:00 PM', '02:30 PM', '04:00 PM', '05:30 PM'
];

export default function Booking() {
  const { user, loading: authLoading } = useAuth();
  const { currentMood } = useMood();
  const navigate = useNavigate();
  const [step, setStep] = useState<Step>('auth');
  const [selectedService, setSelectedService] = useState<Service | null>(null);
  const [selectedCounsellor, setSelectedCounsellor] = useState<Counsellor | null>(null);
  const [selectedDate, setSelectedDate] = useState<string | null>(null);
  const [selectedSlot, setSelectedSlot] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [holdTime, setHoldTime] = useState(600); // 10 minutes hold

  const [bloomData, setBloomData] = useState<any>(null);

  useEffect(() => {
    fetch("https://assets9.lottiefiles.com/packages/lf20_u4yrau.json")
      .then(res => res.json())
      .then(data => setBloomData(data))
      .catch(err => console.error('Lottie load error:', err));
  }, []);

  // Payment System Flag
  const paymentReady = false;

  useEffect(() => {
    if (user && step === 'auth') {
      setStep('service');
    }
  }, [user, step]);

  useEffect(() => {
    let timer: any;
    if (step === 'payment' && holdTime > 0) {
      timer = setInterval(() => setHoldTime(prev => prev - 1), 1000);
    }
    return () => clearInterval(timer);
  }, [step, holdTime]);

  const handleGoogleSignIn = async () => {
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (error) {
      console.error('Sign in error:', error);
    }
  };

  const handlePayment = async () => {
    if (!user) return;
    setIsProcessing(true);
    
    // Razorpay onSuccess Callback Simulation
    const onRazorpaySuccess = async (response: any) => {
      try {
        // 1. Save to Firestore
        const appointmentRef = await addDoc(collection(db, 'appointments'), {
          clientUid: user.uid,
          clientEmail: user.email,
          counsellorId: selectedCounsellor?.id,
          counsellorName: selectedCounsellor?.name,
          service: selectedService,
          date: selectedDate,
          slot: selectedSlot,
          status: 'confirmed',
          amount: 800,
          paymentStatus: 'paid',
          razorpayPaymentId: response.razorpay_payment_id,
          createdAt: serverTimestamp(),
        });

        // 2. Automation & Calendar Integration (Simulated Webhook/Backend Logic)
        // In a real app, this would trigger a Cloud Function to:
        // - Finalize Google Calendar slot
        // - Generate unique GMeet link
        // - Send Confirmation Email (Alabaster Silk & Deep Moss theme)
        console.log('Finalizing Calendar & Generating GMeet link...');

        setIsProcessing(false);
        setStep('success');
      } catch (error) {
        console.error('Booking error:', error);
        setIsProcessing(false);
      }
    };

    // Simulate Razorpay processing delay
    setTimeout(() => {
      onRazorpaySuccess({ razorpay_payment_id: 'pay_' + Math.random().toString(36).substr(2, 9) });
    }, 2500);
  };

  const formatHoldTime = (s: number) => {
    const m = Math.floor(s / 60);
    const sec = s % 60;
    return `${m}:${sec.toString().padStart(2, '0')}`;
  };

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-moss-black">
        <Loader2 className="w-10 h-10 text-sage-ethereal animate-spin" />
      </div>
    );
  }

  return (
    <PageTransition>
      <div className="min-h-screen bg-moss-black pt-32 pb-40 px-6">
        <div className="max-w-4xl mx-auto">
          {/* Progress Header */}
          <div className="mb-16 flex items-center justify-between">
            <div className="flex items-center gap-4">
              {step !== 'auth' && step !== 'service' && step !== 'success' && (
                <button 
                  onClick={() => {
                    if (step === 'counsellor') setStep('service');
                    if (step === 'calendar') setStep('counsellor');
                    if (step === 'payment') setStep('calendar');
                  }}
                  className="w-10 h-10 rounded-full border border-off-white/10 flex items-center justify-center text-off-white/60 hover:text-off-white hover:border-off-white/30 transition-all"
                >
                  <ArrowLeft size={18} />
                </button>
              )}
              <div>
                <h1 className="text-3xl font-serif font-bold text-off-white tracking-tight">
                  {step === 'auth' && 'Identify Yourself'}
                  {step === 'service' && 'Choose Your Path'}
                  {step === 'counsellor' && 'Select Your Guide'}
                  {step === 'calendar' && 'Find Your Moment'}
                  {step === 'payment' && 'Secure Your Space'}
                  {step === 'success' && 'You\'re Booked'}
                </h1>
                <p className="text-off-white/40 text-xs uppercase tracking-[0.3em] mt-1">
                  {step === 'auth' ? 'Verification' : `Step ${['service', 'counsellor', 'calendar', 'payment'].indexOf(step) + 1} of 4`}
                </p>
              </div>
            </div>
            
            <div className="hidden md:flex gap-2">
              {['service', 'counsellor', 'calendar', 'payment'].map((s, i) => (
                <div 
                  key={s}
                  className={`h-1 w-12 rounded-full transition-all duration-500 ${
                    step === s ? 'bg-white w-20' : i < ['service', 'counsellor', 'calendar', 'payment'].indexOf(step) ? 'bg-white/40' : 'bg-white/10'
                  }`}
                  style={{ backgroundColor: step === s ? currentMood.color : undefined }}
                />
              ))}
            </div>
          </div>

          <AnimatePresence mode="wait">
            {/* Step 0: Auth */}
            {step === 'auth' && (
              <motion.div
                key="step-auth"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="max-w-md mx-auto p-10 bg-off-white/5 border border-off-white/10 rounded-[48px] text-center"
              >
                <div className="w-16 h-16 bg-white/5 rounded-full flex items-center justify-center mx-auto mb-8">
                  <ShieldCheck size={32} className="text-off-white/40" />
                </div>
                <h2 className="text-2xl font-serif font-bold text-off-white mb-4">Secure Entry</h2>
                <p className="text-off-white/40 text-sm mb-10 leading-relaxed">
                  We use Google Sign-In to keep your sanctuary private and your data secure.
                </p>
                <button 
                  onClick={handleGoogleSignIn}
                  className="w-full flex items-center justify-center gap-4 bg-white text-stone-900 py-5 rounded-2xl font-bold hover:bg-stone-100 transition-all shadow-xl"
                >
                  <img src="https://www.google.com/favicon.ico" className="w-5 h-5" alt="Google" />
                  Continue with Google
                </button>
              </motion.div>
            )}

            {/* Step 1: Service Selection */}
            {step === 'service' && (
              <motion.div
                key="step-service"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="grid grid-cols-1 md:grid-cols-3 gap-6"
              >
                {services.map((service) => (
                  <button
                    key={service.id}
                    onClick={() => {
                      setSelectedService(service.id as Service);
                      setStep('counsellor');
                    }}
                    className="group p-8 bg-off-white/5 border border-off-white/10 rounded-[40px] text-left hover:bg-off-white/10 hover:border-off-white/30 transition-all relative overflow-hidden"
                  >
                    <div className="w-12 h-12 rounded-2xl bg-off-white/5 flex items-center justify-center text-off-white/60 group-hover:scale-110 transition-transform mb-6">
                      <service.icon size={24} />
                    </div>
                    <h3 className="text-xl font-serif font-bold text-off-white mb-2">{service.name}</h3>
                    <p className="text-off-white/40 text-sm leading-relaxed">{service.desc}</p>
                    <div className="absolute bottom-6 right-6 opacity-0 group-hover:opacity-100 transition-opacity">
                      <ChevronRight size={20} className="text-off-white" />
                    </div>
                  </button>
                ))}
              </motion.div>
            )}

            {/* Step 2: Counsellor Selection */}
            {step === 'counsellor' && (
              <motion.div
                key="step-counsellor"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-6"
              >
                {counsellors.map((c) => (
                  <button
                    key={c.id}
                    onClick={() => {
                      setSelectedCounsellor(c);
                      setStep('calendar');
                    }}
                    className="w-full group p-6 bg-off-white/5 border border-off-white/10 rounded-[40px] flex items-center gap-6 text-left hover:bg-off-white/10 transition-all relative overflow-hidden"
                  >
                    <div className="w-24 h-24 rounded-[32px] overflow-hidden shrink-0 border border-off-white/10">
                      <img src={c.img} alt={c.name} className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-700" />
                    </div>
                    <div className="flex-grow">
                      <h3 className="text-2xl font-serif font-bold text-off-white">{c.name}</h3>
                      <p className="text-off-white/40 text-xs uppercase tracking-widest mt-1">{c.role}</p>
                      <div className="flex gap-2 mt-4">
                        <span className="px-3 py-1 bg-off-white/5 rounded-full text-[10px] font-bold text-off-white/40 border border-off-white/10">Available Today</span>
                        <span className="px-3 py-1 bg-off-white/5 rounded-full text-[10px] font-bold text-off-white/40 border border-off-white/10">Top Rated</span>
                      </div>
                    </div>
                    <div className="absolute right-8 top-1/2 -translate-y-1/2 w-12 h-12 rounded-full bg-white/5 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all group-hover:translate-x-2">
                      <ChevronRight size={24} className="text-off-white" />
                    </div>
                  </button>
                ))}
              </motion.div>
            )}

            {/* Step 3: Calendar & Slots */}
            {step === 'calendar' && (
              <motion.div
                key="step-calendar"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="grid grid-cols-1 md:grid-cols-2 gap-12"
              >
                {/* Date Picker */}
                <div className="space-y-6">
                  <h3 className="text-sm font-bold uppercase tracking-[0.3em] text-off-white/40">Select Date</h3>
                  <div className="grid grid-cols-4 gap-4">
                    {[17, 18, 19, 20, 21, 22, 23, 24].map((day) => (
                      <button
                        key={day}
                        onClick={() => setSelectedDate(`March ${day}`)}
                        className={`aspect-square rounded-3xl flex flex-col items-center justify-center gap-1 transition-all border ${
                          selectedDate === `March ${day}` 
                          ? 'bg-white text-stone-900 border-white' 
                          : 'bg-off-white/5 text-off-white/60 border-off-white/10 hover:border-off-white/40'
                        }`}
                      >
                        <span className="text-xs font-bold uppercase opacity-60">Mar</span>
                        <span className="text-xl font-serif font-bold">{day}</span>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Slot Picker */}
                <div className="space-y-6">
                  <h3 className="text-sm font-bold uppercase tracking-[0.3em] text-off-white/40">Available Slots</h3>
                  <div className="grid grid-cols-2 gap-4">
                    {timeSlots.map((slot) => (
                      <button
                        key={slot}
                        onClick={() => setSelectedSlot(slot)}
                        className={`py-4 rounded-2xl text-xs font-bold tracking-widest transition-all border ${
                          selectedSlot === slot 
                          ? 'bg-white text-stone-900 border-white shadow-[0_0_20px_rgba(255,255,255,0.3)]' 
                          : 'bg-off-white/5 text-off-white/60 border-off-white/10 hover:border-off-white/40'
                        }`}
                      >
                        {slot}
                      </button>
                    ))}
                  </div>
                  
                  {selectedSlot && (
                    <motion.button
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      onClick={() => setStep('payment')}
                      className="w-full mt-8 py-5 bg-white text-stone-900 rounded-3xl font-bold text-sm uppercase tracking-widest hover:bg-stone-100 transition-all flex items-center justify-center gap-3"
                      style={{ backgroundColor: currentMood.color, color: 'white' }}
                    >
                      Confirm Details
                      <ChevronRight size={18} />
                    </motion.button>
                  )}
                </div>
              </motion.div>
            )}

            {/* Step 4: Payment Overlay */}
            {step === 'payment' && (
              <motion.div
                key="step-payment"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="max-w-md mx-auto"
              >
                <div className="p-10 bg-white rounded-[48px] text-stone-900 shadow-2xl relative overflow-hidden">
                  {/* Razorpay Simulation Header */}
                  <div className="flex items-center justify-between mb-10">
                    <div className="flex items-center gap-2">
                      <ShieldCheck size={20} className="text-blue-600" />
                      <span className="text-[10px] font-bold uppercase tracking-widest text-stone-400">Secure Checkout</span>
                    </div>
                    <div className="text-right">
                      <p className="text-[10px] uppercase tracking-widest text-stone-400">Amount Due</p>
                      <h4 className="text-2xl font-serif font-bold">₹800/-</h4>
                    </div>
                  </div>

                  {/* QR Code Placeholder */}
                  <div className="aspect-square bg-stone-50 rounded-[40px] border-2 border-dashed border-stone-200 flex flex-col items-center justify-center gap-6 relative group overflow-hidden">
                    <AnimatePresence>
                      {isProcessing ? (
                        <motion.div 
                          initial={{ opacity: 0 }}
                          animate={{ opacity: 1 }}
                          className="absolute inset-0 bg-white/80 backdrop-blur-sm flex flex-col items-center justify-center z-20"
                        >
                          <div className="w-16 h-16 border-4 border-stone-100 border-t-stone-900 rounded-full animate-spin mb-4" />
                          <p className="text-[10px] font-bold uppercase tracking-widest text-stone-600">Verifying Payment...</p>
                        </motion.div>
                      ) : (
                        <>
                          <QrCode size={120} strokeWidth={1} className="text-stone-300 group-hover:scale-110 transition-transform duration-700" />
                          <div className="text-center">
                            <p className="text-xs font-bold text-stone-800">Scan to Pay via UPI</p>
                            <p className="text-[10px] text-stone-400 mt-1">GPay, PhonePe, Paytm</p>
                          </div>
                        </>
                      )}
                    </AnimatePresence>
                  </div>

                  {/* Hold Timer */}
                  <div className="mt-8 flex items-center justify-center gap-2 text-stone-400">
                    <Clock size={14} />
                    <span className="text-[10px] font-bold uppercase tracking-widest">
                      Slot held for {formatHoldTime(holdTime)}
                    </span>
                  </div>

                  <button
                    onClick={handlePayment}
                    className="w-full mt-10 py-5 bg-stone-900 text-white rounded-3xl font-bold text-sm uppercase tracking-widest hover:bg-stone-800 transition-all flex items-center justify-center gap-3"
                  >
                    <Zap size={18} />
                    Simulate Success
                  </button>

                  {!paymentReady && (
                    <p className="mt-4 text-center text-[10px] text-stone-400 italic">
                      Payment system in sandbox mode.
                    </p>
                  )}
                </div>
              </motion.div>
            )}

            {/* Step 5: Success Animation & Confirmation Logic */}
            {step === 'success' && (
              <motion.div
                key="step-success"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="text-center py-12 relative"
              >
                {/* Matcha Green Glow Background */}
                <div className="absolute inset-0 -z-10 blur-[150px] opacity-30 pointer-events-none" style={{ background: 'radial-gradient(circle, #789D9E 0%, transparent 70%)' }} />

                <div className="relative inline-block mb-8">
                  <div className="w-40 h-40 mx-auto flex items-center justify-center">
                    {bloomData ? (
                      <Lottie 
                        animationData={bloomData}
                        loop={false}
                      />
                    ) : (
                      <motion.div
                        initial={{ scale: 0, rotate: -180 }}
                        animate={{ scale: 1, rotate: 0 }}
                        transition={{ type: 'spring', damping: 15, stiffness: 100 }}
                        className="text-green-400"
                      >
                        <Sparkles size={80} />
                      </motion.div>
                    )}
                  </div>
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ type: 'spring', damping: 12, delay: 0.5 }}
                    className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-20 h-20 bg-green-500 rounded-full flex items-center justify-center text-white shadow-2xl shadow-green-500/40"
                  >
                    <CheckCircle2 size={40} />
                  </motion.div>
                </div>

                <h2 className="text-5xl md:text-6xl font-serif font-bold text-off-white mb-4 tracking-tighter">
                  Confirmed.
                </h2>
                <p className="text-off-white/80 text-2xl font-serif italic mb-12">
                  Your growth journey starts on <span className="text-green-400">{selectedDate}</span> at <span className="text-green-400">{selectedSlot}</span>.
                </p>

                {/* Next Steps Card */}
                <div className="max-w-2xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-6 mb-16">
                  <div className="p-8 bg-off-white/5 border border-off-white/10 rounded-[40px] flex flex-col items-center gap-4 group hover:bg-off-white/10 transition-all">
                    <div className="w-12 h-12 rounded-2xl bg-off-white/5 flex items-center justify-center text-off-white/40 group-hover:text-green-400 transition-colors">
                      <Mail size={24} />
                    </div>
                    <p className="text-xs font-bold text-off-white/60 leading-relaxed uppercase tracking-widest">Check Email for GMeet Link</p>
                  </div>
                  <div className="p-8 bg-off-white/5 border border-off-white/10 rounded-[40px] flex flex-col items-center gap-4 group hover:bg-off-white/10 transition-all">
                    <div className="w-12 h-12 rounded-2xl bg-off-white/5 flex items-center justify-center text-off-white/40 group-hover:text-green-400 transition-colors">
                      <FileText size={24} />
                    </div>
                    <p className="text-xs font-bold text-off-white/60 leading-relaxed uppercase tracking-widest">Complete Intake Form</p>
                  </div>
                  <div className="p-8 bg-off-white/5 border border-off-white/10 rounded-[40px] flex flex-col items-center gap-4 group hover:bg-off-white/10 transition-all">
                    <div className="w-12 h-12 rounded-2xl bg-off-white/5 flex items-center justify-center text-off-white/40 group-hover:text-green-400 transition-colors">
                      <Download size={24} />
                    </div>
                    <p className="text-xs font-bold text-off-white/60 leading-relaxed uppercase tracking-widest">Download Consent Form</p>
                  </div>
                </div>

                {/* Add to Calendar Button */}
                <div className="mb-12 inline-block">
                  <AddToCalendarButton
                    name={`Counselling with ${selectedCounsellor?.name}`}
                    options={['Apple', 'Google', 'Outlook.com']}
                    location="Google Meet"
                    startDate="2026-03-17"
                    startTime="09:00"
                    endTime="10:00"
                    timeZone="Asia/Kolkata"
                    buttonStyle="round"
                    label="Add to Calendar"
                    lightMode="dark"
                  />
                </div>

                {/* Intake Bridge (Secondary Focus) */}
                <div className="flex flex-col items-center gap-8">
                  <button 
                    className="group flex items-center gap-3 px-8 py-4 bg-off-white/5 border border-off-white/10 rounded-full text-off-white/60 hover:text-off-white hover:bg-off-white/10 transition-all"
                  >
                    <span className="text-sm font-bold uppercase tracking-widest">Help us understand you better (Optional Intake Form)</span>
                    <ArrowUpRight size={18} className="group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
                  </button>

                  <button 
                    onClick={() => navigate('/dashboard')}
                    className="text-xs font-bold uppercase tracking-[0.4em] text-off-white/20 hover:text-off-white/60 transition-colors"
                  >
                    Go to Sanctuary
                  </button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </PageTransition>
  );
}
