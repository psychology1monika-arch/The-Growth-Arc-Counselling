import { motion, useScroll, useTransform, AnimatePresence, useMotionValue, useSpring } from 'motion/react';
import { useRef, useState, useEffect } from 'react';
import { ArrowRight, Sparkles, Brain, Target, Zap, Heart, Users, MessageCircle, X, ArrowUpRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import PageTransition from '../components/PageTransition';
import { DoodlePlant, DoodleHeart, DoodleBrain, DoodleSparkle, DoodleArc, DoodleTangle, DoodleCloud, DoodleSun } from '../components/Doodles';
import { useMood } from '../contexts/MoodContext';

function cn(...inputs: any[]) {
  return inputs.filter(Boolean).join(' ');
}

const MagneticButton = ({ children, className = "", to = "/booking" }: { children: React.ReactNode, className?: string, to?: string }) => {
  const mouseX = useMotionValue(0);
  const mouseY = useMotionValue(0);
  const { currentMood } = useMood();

  const springConfig = { damping: 15, stiffness: 150 };
  const x = useSpring(mouseX, springConfig);
  const y = useSpring(mouseY, springConfig);

  const handleMouseMove = (e: React.MouseEvent) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;
    mouseX.set((e.clientX - centerX) * 0.4);
    mouseY.set((e.clientY - centerY) * 0.4);
  };

  const handleMouseLeave = () => {
    mouseX.set(0);
    mouseY.set(0);
  };

  return (
    <motion.div
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      style={{ x, y }}
      className="inline-block"
    >
      <Link 
        to={to} 
        className={cn("btn-ghost group relative overflow-hidden px-12 py-6 rounded-full border border-off-white/10", className)}
      >
        <span className="relative z-10 flex items-center gap-3 text-lg font-bold">
          {children}
          <ArrowUpRight size={20} className="group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
        </span>
        <motion.div
          className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity"
          style={{ backgroundColor: `${currentMood.color}22` }}
          initial={false}
        />
      </Link>
    </motion.div>
  );
};

const BentoItem = ({ title, description, doodle: Doodle, className = "", size = "small" }: any) => {
  const [isHovered, setIsHovered] = useState(false);
  const { currentMood } = useMood();
  
  return (
    <motion.div
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      className={cn(
        "bento-item group relative overflow-hidden flex flex-col justify-between p-8 rounded-[40px] bg-off-white/5 border border-off-white/10 transition-all duration-500",
        size === "large" ? "md:col-span-2 md:row-span-2" : size === "wide" ? "md:col-span-2" : "",
        className
      )}
    >
      <div className="relative z-10">
        <h3 className="text-2xl font-serif font-bold text-off-white mb-2 group-hover:text-sage-ethereal transition-colors" style={{ color: isHovered ? currentMood.color : undefined }}>
          {title}
        </h3>
        <p className="text-sm text-off-white/60 leading-relaxed max-w-[200px]">
          {description}
        </p>
      </div>
      
      <div className="absolute bottom-4 right-4 w-24 h-24 opacity-20 group-hover:opacity-100 group-hover:scale-110 transition-all duration-500">
        <Doodle className="w-full h-full" style={{ color: currentMood.color }} isHovered={isHovered} />
      </div>

      <motion.div
        className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none"
        style={{ background: `radial-gradient(circle at center, ${currentMood.color}11 0%, transparent 70%)` }}
      />
    </motion.div>
  );
};

export default function Home() {
  const heroRef = useRef(null);
  const bentoRef = useRef(null);
  const { currentMood } = useMood();
  
  const { scrollYProgress: heroScroll } = useScroll({
    target: heroRef,
    offset: ["start start", "end start"]
  });

  const rotateX = useTransform(heroScroll, [0, 1], [0, 20]);
  const rotateY = useTransform(heroScroll, [0, 1], [0, -10]);
  const scale = useTransform(heroScroll, [0, 1], [1, 0.9]);
  const opacity = useTransform(heroScroll, [0, 0.8], [1, 0]);

  const [bookingCount, setBookingCount] = useState(12);
  const [showQuiz, setShowQuiz] = useState(false);

  useEffect(() => {
    const interval = setInterval(() => {
      setBookingCount(prev => prev + Math.floor(Math.random() * 2));
    }, 10000);
    return () => clearInterval(interval);
  }, []);

  return (
    <PageTransition>
      <div className="relative">
        {/* Hero Section */}
        <section 
          ref={heroRef}
          className="h-screen flex items-center justify-center sticky top-0 perspective-1000 overflow-hidden bg-moss-black"
        >
          <motion.div 
            style={{ rotateX, rotateY, scale, opacity }}
            className="preserve-3d text-center px-4"
          >
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 1, ease: "easeOut" }}
            >
              <h1 className="text-7xl md:text-9xl font-serif font-bold text-off-white leading-tight tracking-tighter mb-8">
                The <span className="italic transition-colors duration-1000" style={{ color: currentMood.color }}>Growth</span> Arc
              </h1>
              <p className="text-lg md:text-xl text-off-white/60 max-w-2xl mx-auto font-sans leading-relaxed mb-12">
                Growth isn't linear. It's an arc that bends toward healing, 
                stability, and self-discovery. We're here to walk it with you.
              </p>
              
              <div className="flex flex-col items-center gap-6">
                <MagneticButton>
                  Start Your Journey
                </MagneticButton>
                <div className="flex items-center gap-3">
                  <div className="flex -space-x-2">
                    {[1,2,3].map(i => (
                      <div key={i} className="w-8 h-8 rounded-full border-2 border-moss-black bg-off-white/10 overflow-hidden">
                        <img src={`https://i.pravatar.cc/100?img=${i+10}`} alt="user" className="w-full h-full object-cover" />
                      </div>
                    ))}
                  </div>
                  <motion.p 
                    animate={{ opacity: [0.4, 1, 0.4] }}
                    transition={{ duration: 3, repeat: Infinity }}
                    className="text-[10px] uppercase tracking-[0.3em] font-bold"
                    style={{ color: currentMood.color }}
                  >
                    {bookingCount} people started their journey this week
                  </motion.p>
                </div>
              </div>
            </motion.div>
          </motion.div>

          {/* Background Doodles */}
          <div className="absolute inset-0 pointer-events-none -z-10 overflow-hidden">
            <motion.div
              animate={{ 
                y: [0, -20, 0],
                rotate: [0, 5, 0]
              }}
              transition={{ duration: 10, repeat: Infinity, ease: "linear" }}
              className="absolute top-1/4 left-10 w-64 h-64 opacity-5"
              style={{ color: currentMood.color }}
            >
              <DoodlePlant className="w-full h-full" />
            </motion.div>
            <motion.div
              animate={{ 
                y: [0, 20, 0],
                rotate: [0, -5, 0]
              }}
              transition={{ duration: 12, repeat: Infinity, ease: "linear" }}
              className="absolute bottom-1/4 right-10 w-80 h-80 opacity-5"
              style={{ color: currentMood.color }}
            >
              <DoodleArc className="w-full h-full" />
            </motion.div>
          </div>
        </section>

        {/* Bento Services Section */}
        <section ref={bentoRef} className="relative z-20 bg-moss-black py-32 px-6">
          <div className="max-w-7xl mx-auto">
            <div className="mb-20">
              <h2 className="text-5xl md:text-7xl font-serif font-bold text-off-white mb-6">
                What We <span className="italic transition-colors duration-1000" style={{ color: currentMood.color }}>Help</span> With
              </h2>
              <p className="text-off-white/40 max-w-xl text-lg">
                Navigating the complexities of the human experience, one step at a time.
              </p>
            </div>

            <div className="bento-grid">
              <BentoItem 
                size="large"
                title="Overthinking"
                description="Taming the endless loops of 'what if' and finding mental clarity."
                doodle={DoodleTangle}
              />
              <BentoItem 
                title="Anxiety"
                description="Learning to breathe through the storm and find your center."
                doodle={DoodleCloud}
              />
              <BentoItem 
                title="Burnout"
                description="Restoring the spark when the world feels too heavy."
                doodle={DoodleSun}
              />
              <BentoItem 
                size="wide"
                title="Self-Discovery"
                description="Uncovering the layers of who you are and who you want to become."
                doodle={DoodleHeart}
              />
              <BentoItem 
                title="Relationships"
                description="Building bridges and understanding the arcs of connection."
                doodle={DoodleArc}
              />
              <BentoItem 
                title="Growth"
                description="Nurturing the seeds of change in a safe, grounded space."
                doodle={DoodlePlant}
              />
            </div>
          </div>
        </section>

        {/* Founder Note Section */}
        <section className="bg-linen py-32 px-6">
          <div className="max-w-5xl mx-auto">
            <div className="grid md:grid-cols-2 gap-20 items-center">
              <div className="relative">
                <div className="aspect-[4/5] bg-moss-black rounded-[40px] overflow-hidden shadow-2xl">
                  <img 
                    src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=800&fm=webp" 
                    alt="Founder" 
                    className="w-full h-full object-cover opacity-80 grayscale hover:grayscale-0 transition-all duration-1000"
                    referrerPolicy="no-referrer"
                  />
                </div>
                <motion.div
                  initial={{ opacity: 0, scale: 0.8 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  className="absolute -bottom-10 -right-10 w-48 h-48 rounded-full flex items-center justify-center p-8 text-white text-center font-serif italic text-lg leading-tight shadow-2xl"
                  style={{ backgroundColor: currentMood.color }}
                >
                  "Healing is a journey, not a destination."
                </motion.div>
              </div>

              <div>
                <span className="font-bold uppercase tracking-[0.3em] text-xs mb-6 block" style={{ color: currentMood.color }}>
                  A Note from Gadadhar
                </span>
                <h2 className="text-4xl md:text-6xl font-serif font-bold text-charcoal-soft mb-8 leading-tight">
                  You don't have to walk the arc <span className="italic" style={{ color: currentMood.color }}>alone</span>.
                </h2>
                <p className="text-charcoal-soft/70 text-lg leading-relaxed mb-12">
                  At The Growth Arc, we believe that every individual has the capacity for profound change. 
                  Our approach is rooted in empathy, evidence-based practices, and a deep respect for 
                  your unique story.
                </p>
                
                <div className="relative">
                  <div className="h-24 w-64" style={{ color: currentMood.color }}>
                    <svg viewBox="0 0 200 100" className="w-full h-full">
                      <motion.path
                        d="M20,50 Q40,20 60,50 T100,50 T140,50 T180,50"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        initial={{ pathLength: 0 }}
                        whileInView={{ pathLength: 1 }}
                        transition={{ duration: 2, ease: "easeInOut" }}
                      />
                    </svg>
                  </div>
                  <p className="text-charcoal-soft font-serif italic text-xl">Gadadhar, Founder</p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* No-Pressure Booking FAB */}
        <div className="fixed bottom-8 right-8 z-[60]">
          <motion.button
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            onClick={() => setShowQuiz(true)}
            className="w-20 h-20 rounded-full flex items-center justify-center text-moss-black shadow-2xl relative group"
            style={{ backgroundColor: currentMood.color }}
          >
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ duration: 10, repeat: Infinity, ease: "linear" }}
              className="absolute inset-0 border-2 border-dashed border-moss-black/20 rounded-full"
            />
            <MessageCircle size={32} />
            
            <div className="absolute -inset-4 opacity-0 group-hover:opacity-100 transition-opacity">
              <svg viewBox="0 0 100 100" className="w-full h-full animate-spin-slow">
                <path id="textPath" d="M 50,50 m -37,0 a 37,37 0 1,1 74,0 a 37,37 0 1,1 -74,0" fill="none" />
                <text className="text-[8px] uppercase tracking-[0.2em] font-bold" style={{ fill: currentMood.color }}>
                  <textPath href="#textPath">Take a breath... Take a step...</textPath>
                </text>
              </svg>
            </div>
          </motion.button>
        </div>

        {/* Quick Vibe Check Modal */}
        <AnimatePresence>
          {showQuiz && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-[100] flex items-center justify-center px-4 bg-moss-black/80 backdrop-blur-xl"
            >
              <motion.div
                initial={{ scale: 0.9, y: 20 }}
                animate={{ scale: 1, y: 0 }}
                exit={{ scale: 0.9, y: 20 }}
                className="bg-linen w-full max-w-lg rounded-[40px] p-10 relative overflow-hidden"
              >
                <button 
                  onClick={() => setShowQuiz(false)}
                  className="absolute top-6 right-6 p-2 hover:bg-moss-black/5 rounded-full transition-colors"
                >
                  <X size={24} className="text-charcoal-soft" />
                </button>

                <div className="text-center">
                  <div className="w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-6" style={{ backgroundColor: `${currentMood.color}22` }}>
                    <Sparkles style={{ color: currentMood.color }} />
                  </div>
                  <h2 className="text-3xl font-serif font-bold text-charcoal-soft mb-4">Quick Vibe Check</h2>
                  <p className="text-charcoal-soft/60 mb-8">Let's find the right path for you. No pressure, just a breath.</p>

                  <div className="space-y-4">
                    <button className="w-full p-6 rounded-2xl border-2 border-charcoal-soft/5 hover:bg-sage-ethereal/5 transition-all text-left flex items-center justify-between group" style={{ borderColor: `${currentMood.color}11` }}>
                      <span className="font-bold text-charcoal-soft">I'm feeling overwhelmed</span>
                      <ArrowRight size={20} className="opacity-0 group-hover:opacity-100 transition-all" style={{ color: currentMood.color }} />
                    </button>
                    <button className="w-full p-6 rounded-2xl border-2 border-charcoal-soft/5 hover:bg-sage-ethereal/5 transition-all text-left flex items-center justify-between group" style={{ borderColor: `${currentMood.color}11` }}>
                      <span className="font-bold text-charcoal-soft">I want to grow personally</span>
                      <ArrowRight size={20} className="opacity-0 group-hover:opacity-100 transition-all" style={{ color: currentMood.color }} />
                    </button>
                    <button className="w-full p-6 rounded-2xl border-2 border-charcoal-soft/5 hover:bg-sage-ethereal/5 transition-all text-left flex items-center justify-between group" style={{ borderColor: `${currentMood.color}11` }}>
                      <span className="font-bold text-charcoal-soft">I need relationship support</span>
                      <ArrowRight size={20} className="opacity-0 group-hover:opacity-100 transition-all" style={{ color: currentMood.color }} />
                    </button>
                  </div>

                  <Link
                    to="/booking"
                    onClick={() => setShowQuiz(false)}
                    className="mt-10 block w-full py-4 bg-moss-black text-off-white rounded-2xl font-bold text-lg hover:opacity-90 transition-all"
                    style={{ backgroundColor: currentMood.color }}
                  >
                    Skip to Booking
                  </Link>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </PageTransition>
  );
}
