import { motion, useScroll, useSpring, useTransform, AnimatePresence, useVelocity } from 'motion/react';
import { useRef, useState, useEffect } from 'react';
import { ArrowRight, Clock, Calendar, Sparkles, X, Share2, Bookmark } from 'lucide-react';
import PageTransition from '../components/PageTransition';
import { DoodleArc, DoodleSparkle, DoodleBrain, DoodleHeart, DoodlePlant } from '../components/Doodles';
import { useMood } from '../contexts/MoodContext';

const posts = [
  {
    id: 1,
    title: 'The Future of Healing: Why Online Counselling is Transforming Mental Health Support',
    excerpt: 'Online counselling is no longer just a convenience; it is a powerful tool for accessibility and personalized care.',
    content: 'Online counselling is no longer just a convenience; it is a powerful tool for accessibility and personalized care. In an increasingly digital world, the ability to connect with a professional from the comfort of your own space can break down significant barriers to entry. Whether it\'s the stigma associated with visiting a clinic, physical mobility issues, or simply a busy schedule, digital therapy offers a flexible and effective alternative.',
    date: 'Oct 12, 2023',
    readTime: '5 min read',
    category: 'Mental Health',
    img: 'https://images.unsplash.com/photo-1518173946687-a4c8892bbd9f?auto=format&fit=crop&q=80&w=800&fm=webp', // Water ripples (Calm)
    doodle: DoodleArc
  },
  {
    id: 2,
    title: 'How to Deal With Constant Overthinking',
    excerpt: 'Have you ever replayed a conversation again and again in your mind? Your thoughts keep running in circles, and before you realize it, you feel mentally exhausted.',
    content: `Have you ever replayed a conversation again and again in your mind?

Maybe you keep wondering, “Did I say something wrong?” or “What if things go badly tomorrow?” Your thoughts keep running in circles, and before you realize it, you feel mentally exhausted.

If this sounds familiar, you are not alone. Many people experience constant overthinking, especially in today’s fast-paced world.

Overthinking usually begins as a way of trying to understand a situation better. But instead of helping us find solutions, it can trap us in a cycle of worry and self-doubt.

Why Do We Overthink?

Our brain naturally tries to protect us from mistakes and uncertainty. When we feel stressed or unsure about something, the mind starts analyzing every possible outcome.

Some common reasons for overthinking include:
• Fear of making the wrong decision
• Worry about the future
• Stress from work or personal life
• Low self-confidence
• Past negative experiences

Instead of helping us move forward, these thoughts often keep us stuck in the same mental loop.

Signs You Might Be Overthinking

You might be experiencing overthinking if you notice:
✔ Replaying past conversations repeatedly
✔ Imagining worst-case scenarios
✔ Difficulty making decisions
✔ Trouble sleeping because your mind keeps racing
✔ Feeling mentally drained even without physical work

Over time, this pattern can increase stress, anxiety, and emotional fatigue.

Simple Ways to Manage Overthinking

Although overthinking can feel overwhelming, small changes can help calm the mind.

1. Notice the Pattern
The first step is becoming aware of when your mind starts repeating the same thoughts.

2. Focus on What You Can Control
Many worries involve things outside our control. Try focusing on actions you can take right now.

3. Take Breaks From Your Thoughts
Activities like walking, exercising, or listening to music can help reset your mind.

4. Write Down Your Thoughts
Journaling helps organize worries and often makes them feel less overwhelming.

5. Talk to Someone You Trust
Sharing your thoughts with a trusted friend or counsellor can help you gain a healthier perspective.

When Overthinking Becomes Too Much

Sometimes overthinking can begin to affect sleep, work, and relationships. When thoughts feel difficult to control, seeking support can help.

Counselling provides a safe space to understand your thought patterns and learn healthier ways to manage stress and anxiety.

A Gentle Reminder

Overthinking does not mean there is something wrong with you. It simply means your mind is trying to process experiences and protect you from uncertainty.

With awareness, patience, and the right support, it is possible to create a calmer and more balanced relationship with your thoughts.

Need Support?

If constant overthinking is affecting your daily life, professional guidance can help you regain clarity and emotional balance.

Book an online counselling session with The Growth Arc Counselling.`,
    date: 'Mar 17, 2026',
    readTime: '6 min read',
    category: 'Mental Health',
    img: 'https://images.unsplash.com/photo-1499209974431-9dac3adaf471?auto=format&fit=crop&q=80&w=800&fm=webp', // Abstract brain-like texture
    doodle: DoodleBrain
  },
  {
    id: 3,
    title: 'Navigating Identity in Your 20s',
    excerpt: 'The "quarter-life crisis" is real, but it is also a fertile ground for self-discovery and growth.',
    content: 'The "quarter-life crisis" is real, but it is also a fertile ground for self-discovery and growth. Early adulthood is a period of intense transition. From finishing education to starting a career and navigating complex relationships, the pressure to "have it all figured out" can be overwhelming. However, this uncertainty is also an invitation to explore who you truly are, independent of societal expectations.',
    date: 'Sep 28, 2023',
    readTime: '7 min read',
    category: 'Self-Growth',
    img: 'https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&q=80&w=800&fm=webp', // Architectural space (Overwhelmed)
    doodle: DoodleSparkle
  },
  {
    id: 4,
    title: 'Burnout Prevention for Professionals',
    excerpt: 'Practical strategies to maintain your mental well-being in a high-pressure work environment.',
    content: 'Practical strategies to maintain your mental well-being in a high-pressure work environment. Burnout is more than just being tired. It\'s a state of emotional, physical, and mental exhaustion caused by excessive and prolonged stress. In today\'s "always-on" culture, setting boundaries is not just a luxury—it\'s a necessity for survival and long-term success.',
    date: 'Sep 15, 2023',
    readTime: '6 min read',
    category: 'Workplace',
    img: 'https://images.unsplash.com/photo-1501004318641-b39e6451bec6?auto=format&fit=crop&q=80&w=800&fm=webp', // Botanical leaves (Burnt Out)
    doodle: DoodleBrain
  },
  {
    id: 5,
    title: 'The Power of Vulnerability',
    excerpt: 'Embracing our imperfections is the key to authentic connection and inner peace.',
    content: 'Embracing our imperfections is the key to authentic connection and inner peace. Vulnerability is often mistaken for weakness, but in reality, it is our greatest measure of courage. When we allow ourselves to be seen—truly seen—we open the door to deeper relationships and a more profound sense of belonging.',
    date: 'Aug 22, 2023',
    readTime: '8 min read',
    category: 'Emotional Wellness',
    img: 'https://images.unsplash.com/photo-1515549832467-8783363e19b6?auto=format&fit=crop&q=80&w=800&fm=webp', // Grounded texture (Anxious)
    doodle: DoodleHeart
  }
];

export default function Blog() {
  const containerRef = useRef(null);
  const { currentMood } = useMood();
  const { scrollYProgress } = useScroll();
  
  const scaleX = useSpring(scrollYProgress, {
    stiffness: 100,
    damping: 30,
    restDelta: 0.001
  });

  const scrollVelocity = useVelocity(scrollYProgress);
  const smoothVelocity = useSpring(scrollVelocity, {
    damping: 50,
    stiffness: 400
  });

  const scrollHeight = useTransform(smoothVelocity, [-1, 0, 1], [100, 40, 100]);
  const scrollY = useTransform(scrollYProgress, [0, 1], ["0%", "100%"]);

  const [selectedPost, setSelectedPost] = useState<any>(null);

  return (
    <PageTransition>
      <div className="min-h-screen bg-moss-black pt-32 pb-40 relative" ref={containerRef}>
        {/* Reading Progress Bar (Mood Colored) */}
        <motion.div 
          className="fixed top-0 left-0 right-0 h-1 z-[100] origin-left"
          style={{ 
            scaleX,
            backgroundColor: currentMood.color,
            boxShadow: `0 0 20px ${currentMood.color}66`
          }}
        />

        {/* Custom Kinetic Scrollbar */}
        <div className="fixed right-4 top-1/4 bottom-1/4 w-[2px] bg-off-white/5 z-[100] hidden md:block">
          <motion.div 
            className="absolute left-1/2 -translate-x-1/2 w-1 rounded-full"
            style={{ 
              top: scrollY,
              height: scrollHeight,
              backgroundColor: currentMood.color,
              boxShadow: `0 0 15px ${currentMood.color}`
            }}
          />
        </div>

        <div className="max-w-7xl mx-auto px-6">
          <div className="mb-32">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="max-w-3xl"
            >
              <div className="inline-flex items-center gap-2 px-4 py-2 bg-sage-ethereal/10 text-sage-ethereal rounded-full text-[10px] font-bold uppercase tracking-[0.3em] mb-8">
                <Sparkles size={14} style={{ color: currentMood.color }} />
                <span>Journal Club</span>
              </div>
              <h1 className="text-6xl md:text-9xl font-serif font-bold text-off-white mb-8 leading-[0.85] tracking-tighter">
                Reflections on the <span className="italic" style={{ color: currentMood.color }}>Arc</span>.
              </h1>
              <p className="text-off-white/40 text-xl leading-relaxed max-w-2xl">
                A collection of thoughts, research, and stories to help you navigate 
                your own journey of growth and self-discovery.
              </p>
            </motion.div>
          </div>

          {/* Horizontal Scroll Timeline */}
          <div className="flex overflow-x-auto pb-20 gap-12 snap-x cursor-grab active:cursor-grabbing">
            {posts.map((post, i) => (
              <motion.div
                key={post.id}
                initial={{ opacity: 0, x: 50 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.1, duration: 0.8 }}
                onClick={() => setSelectedPost(post)}
                className="flex-shrink-0 w-[320px] md:w-[500px] snap-center group cursor-pointer"
              >
                <div className="relative mb-12">
                  <div className="aspect-[4/5] rounded-[60px] overflow-hidden bg-off-white/5 border border-off-white/10 shadow-2xl group-hover:border-sage-ethereal/30 transition-all duration-700 relative z-10">
                    <div className="absolute inset-0 p-20 opacity-10 group-hover:opacity-100 group-hover:scale-110 transition-all duration-700">
                      <post.doodle className="w-full h-full" style={{ color: currentMood.color }} />
                    </div>
                    <img 
                      src={post.img} 
                      alt={post.title} 
                      className="absolute inset-0 w-full h-full object-cover opacity-0 group-hover:opacity-100 transition-opacity duration-1000"
                      referrerPolicy="no-referrer"
                    />
                  </div>
                  {/* Timeline Node */}
                  <div 
                    className="absolute -bottom-6 left-1/2 -translate-x-1/2 w-3 h-3 rounded-full transition-transform group-hover:scale-150" 
                    style={{ 
                      backgroundColor: currentMood.color,
                      boxShadow: `0 0 20px ${currentMood.color}99`
                    }}
                  />
                  <div className="absolute -bottom-6 left-0 right-0 h-[1px] bg-off-white/10 -z-10" />
                </div>

                <div className="space-y-4 px-2">
                  <div className="flex items-center gap-4 text-[10px] font-bold uppercase tracking-[0.2em]" style={{ color: currentMood.color }}>
                    <span>{post.category}</span>
                    <span className="w-1 h-1 rounded-full" style={{ backgroundColor: `${currentMood.color}66` }} />
                    <span>{post.readTime}</span>
                  </div>
                  <h2 className="text-3xl md:text-4xl font-serif font-bold text-off-white leading-tight group-hover:text-sage-ethereal transition-colors">
                    {post.title}
                  </h2>
                  <p className="text-off-white/40 text-sm line-clamp-2 leading-relaxed">
                    {post.excerpt}
                  </p>
                </div>
              </motion.div>
            ))}
            
            {/* End Node */}
            <div className="flex-shrink-0 w-64 flex items-center justify-center">
              <div className="text-center">
                <DoodlePlant className="w-16 h-16 text-clay-muted/20 mx-auto mb-4" />
                <p className="text-off-white/20 text-xs uppercase tracking-widest">More to come</p>
              </div>
            </div>
          </div>
        </div>

        {/* Liquid Reveal Modal */}
        <AnimatePresence>
          {selectedPost && (
            <div className="fixed inset-0 z-[200] flex items-center justify-center">
              <motion.div
                initial={{ clipPath: 'circle(0% at 50% 50%)' }}
                animate={{ clipPath: 'circle(150% at 50% 50%)' }}
                exit={{ clipPath: 'circle(0% at 50% 50%)' }}
                transition={{ duration: 1, ease: [0.76, 0, 0.24, 1] }}
                className="absolute inset-0 bg-linen overflow-y-auto"
              >
                <div className="max-w-4xl mx-auto px-6 py-32 relative">
                  <div className="fixed top-8 left-0 right-0 flex justify-between px-8 pointer-events-none z-[210]">
                    <button 
                      onClick={() => setSelectedPost(null)}
                      className="w-14 h-14 bg-moss-black text-off-white rounded-full flex items-center justify-center hover:scale-110 transition-transform pointer-events-auto shadow-2xl"
                    >
                      <X size={24} />
                    </button>
                    <div className="flex gap-4 pointer-events-auto">
                      <button className="w-14 h-14 bg-white text-moss-black rounded-full flex items-center justify-center hover:scale-110 transition-transform shadow-xl">
                        <Bookmark size={20} />
                      </button>
                      <button className="w-14 h-14 bg-white text-moss-black rounded-full flex items-center justify-center hover:scale-110 transition-transform shadow-xl">
                        <Share2 size={20} />
                      </button>
                    </div>
                  </div>

                  <motion.div
                    initial={{ opacity: 0, y: 30 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.5, duration: 0.8 }}
                    className="space-y-16"
                  >
                    <div className="space-y-8">
                      <div className="flex items-center gap-4 text-xs font-bold uppercase tracking-[0.3em]" style={{ color: currentMood.color }}>
                        <span>{selectedPost.category}</span>
                        <span className="w-1 h-1 rounded-full" style={{ backgroundColor: `${currentMood.color}66` }} />
                        <span>{selectedPost.date}</span>
                        <span className="w-1 h-1 rounded-full" style={{ backgroundColor: `${currentMood.color}66` }} />
                        <span>{selectedPost.readTime}</span>
                      </div>
                      <h1 className="text-5xl md:text-8xl font-serif font-bold text-charcoal-soft leading-[0.9] tracking-tighter">
                        {selectedPost.title}
                      </h1>
                    </div>

                    <div className="aspect-[16/9] rounded-[60px] overflow-hidden shadow-2xl relative">
                      <img 
                        src={selectedPost.img} 
                        alt={selectedPost.title} 
                        className="w-full h-full object-cover"
                        referrerPolicy="no-referrer"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-moss-black/40 to-transparent" />
                    </div>

                    <div className="max-w-3xl mx-auto">
                      <p className="text-3xl font-serif italic text-charcoal-soft/80 mb-16 leading-tight border-l-4 pl-8" style={{ borderColor: currentMood.color }}>
                        {selectedPost.excerpt}
                      </p>
                      <div className="prose prose-xl prose-stone max-w-none text-charcoal-soft/70 leading-relaxed space-y-12 font-sans">
                        {selectedPost.content.split('\n\n').map((paragraph: string, idx: number) => (
                          <p key={idx}>{paragraph}</p>
                        ))}
                        <p>
                          The journey of growth is rarely a straight line. It's filled with peaks and valleys, 
                          moments of profound clarity and periods of deep uncertainty. At The Growth Arc, 
                          we believe that every step—even the ones that feel like setbacks—is a vital part 
                          of your personal evolution.
                        </p>
                        <div className="flex items-center gap-6 py-12 border-t border-charcoal-soft/10">
                          <div className="w-16 h-16 rounded-full flex items-center justify-center" style={{ backgroundColor: `${currentMood.color}22` }}>
                            <selectedPost.doodle className="w-8 h-8" style={{ color: currentMood.color }} />
                          </div>
                          <div>
                            <p className="text-sm font-bold uppercase tracking-widest text-charcoal-soft">Written by The Arc Team</p>
                            <p className="text-xs text-charcoal-soft/40">Dedicated to your mental wellness journey.</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </motion.div>
                </div>
              </motion.div>
            </div>
          )}
        </AnimatePresence>
      </div>
    </PageTransition>
  );
}
