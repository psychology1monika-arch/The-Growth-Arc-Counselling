import { motion } from 'motion/react';
import { Shield, Heart, Scale, ArrowRight } from 'lucide-react';
import PageTransition from '../components/PageTransition';

export default function About() {
  return (
    <PageTransition>
      <div className="pt-32 pb-20">
        {/* Hero */}
        <section className="px-6 mb-32">
          <div className="max-w-4xl mx-auto text-center">
            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-5xl md:text-7xl font-serif font-bold text-stone-900 mb-8"
            >
              About The Growth Arc Counselling
            </motion.h1>
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="text-2xl text-stone-600 font-serif italic leading-relaxed"
            >
              "Therapy is not about fixing what is broken. It is about understanding yourself more deeply."
            </motion.p>
          </div>
        </section>

        {/* Philosophy */}
        <section className="section-padding bg-white">
          <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-20 items-center">
            <div className="order-2 lg:order-1">
              <div className="aspect-[4/5] rounded-[40px] overflow-hidden shadow-2xl">
                <img
                  src="https://images.unsplash.com/photo-1499209974431-9dac3adaf471?auto=format&fit=crop&q=80&w=1000"
                  alt="Nature growth"
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              </div>
            </div>
            <div className="order-1 lg:order-2">
              <h2 className="text-4xl font-serif font-bold text-stone-900 mb-8">Our Philosophy</h2>
              <div className="space-y-6 text-stone-600 text-lg leading-relaxed">
                <p>
                  At The Growth Arc Counselling, we believe personal growth rarely follows a straight path. Life brings challenges, uncertainty, and emotional struggles that can feel overwhelming when faced alone.
                </p>
                <p>
                  Our practice provides confidential online counselling for individuals, couples, and professionals across India who are seeking clarity, emotional support, and personal growth.
                </p>
                <p>
                  We believe that meaningful change happens when people feel safe enough to explore their thoughts and emotions without judgment.
                </p>
              </div>
              <div className="mt-12 grid grid-cols-2 gap-6">
                {['Self-awareness', 'Emotional resilience', 'Healthy communication', 'Personal growth'].map((item, i) => (
                  <div key={i} className="flex items-center gap-3 text-stone-800 font-medium">
                    <div className="w-2 h-2 bg-sage-500 rounded-full" />
                    {item}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* Values */}
        <section className="section-padding bg-stone-50">
          <div className="max-w-7xl mx-auto">
            <h2 className="text-4xl font-serif font-bold text-stone-900 mb-16 text-center">Our Core Values</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
              {[
                {
                  title: 'Safety First',
                  desc: 'Every conversation is held within strict confidentiality.',
                  icon: <Shield className="text-sage-600" />
                },
                {
                  title: 'Human Connection',
                  desc: 'We prioritize warmth, empathy, and genuine understanding.',
                  icon: <Heart className="text-sage-600" />
                },
                {
                  title: 'Ethical Integrity',
                  desc: 'We operate within clear professional boundaries and responsible counselling practices.',
                  icon: <Scale className="text-sage-600" />
                }
              ].map((value, i) => (
                <div key={i} className="arc-card text-center">
                  <div className="w-16 h-16 bg-white rounded-2xl shadow-sm flex items-center justify-center mx-auto mb-8 text-sage-600 border border-stone-100">
                    {value.icon}
                  </div>
                  <h3 className="text-2xl font-serif font-bold text-stone-900 mb-4">{value.title}</h3>
                  <p className="text-stone-500 leading-relaxed">{value.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Founder Note */}
        <section className="section-padding bg-white">
          <div className="max-w-5xl mx-auto bg-stone-900 rounded-[60px] p-12 md:p-20 text-white relative overflow-hidden">
            <div className="absolute top-0 right-0 w-64 h-64 bg-sage-500/10 rounded-full blur-3xl" />
            <div className="relative z-10">
              <span className="text-sage-400 uppercase tracking-widest text-sm font-bold mb-6 block">Founder's Note</span>
              <h2 className="text-4xl md:text-5xl font-serif font-bold mb-12">A Growth Arc Perspective</h2>
              <div className="space-y-8 text-stone-300 text-lg leading-relaxed font-light">
                <p>
                  Growth Arc didn’t begin in an office; it began with a conversation between three colleagues about the complexities of the modern workplace and the human psyche. We found ourselves asking: How do we move beyond just "getting by" to truly thriving?
                </p>
                <p>
                  As a student of Freudian thought, I have always been fascinated by the "hidden" drivers of our behavior—the internal maps that dictate our external success. It was during our 60 hours of intensive clinical postings that this fascination turned into a mission.
                </p>
                <p className="text-white font-serif italic text-2xl border-l-4 border-sage-500 pl-8 my-12">
                  "We created Growth Arc to be a bridge between where you are and where you want to be. Our philosophy is simple: we look beneath the surface to understand the roots, so you can reach for the heights."
                </p>
                <p>
                  We don't just help you move past the obstacles. We heal, and we grow. ✨
                </p>
              </div>
              <div className="mt-16 flex items-center gap-6">
                <div className="w-20 h-20 rounded-full overflow-hidden border-2 border-sage-500">
                  <img
                    src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=200"
                    alt="Gadadhar"
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                </div>
                <div>
                  <h4 className="text-xl font-bold">Gadadhar</h4>
                  <p className="text-sage-400 text-sm">Founder, Growth Arc</p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Boundaries */}
        <section className="section-padding bg-stone-50">
          <div className="max-w-4xl mx-auto">
            <div className="bg-white rounded-3xl p-12 border border-stone-200">
              <h2 className="text-3xl font-serif font-bold text-stone-900 mb-8">Professional Boundaries</h2>
              <p className="text-stone-600 mb-8 leading-relaxed">
                Our practice provides non-clinical counselling services only. We are committed to ethical practice and ensuring you receive the appropriate level of care.
              </p>
              <div className="bg-red-50 border-l-4 border-red-200 p-6 rounded-r-xl mb-8">
                <h4 className="text-red-800 font-bold mb-2">We do not provide:</h4>
                <ul className="grid grid-cols-1 md:grid-cols-3 gap-4 text-red-700 text-sm">
                  <li className="flex items-center gap-2">• Psychiatric care</li>
                  <li className="flex items-center gap-2">• Medical advice</li>
                  <li className="flex items-center gap-2">• Emergency crisis services</li>
                </ul>
              </div>
              <p className="text-stone-500 text-sm italic">
                Individuals requiring clinical or emergency support should contact appropriate medical professionals or emergency services immediately.
              </p>
            </div>
          </div>
        </section>
      </div>
    </PageTransition>
  );
}
