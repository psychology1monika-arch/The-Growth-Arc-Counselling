import { motion } from 'motion/react';
import PageTransition from '../components/PageTransition';

export default function Founder() {
  return (
    <PageTransition>
      <div className="pt-32 pb-20 px-6">
        <div className="max-w-4xl mx-auto">
          <div className="mb-16 text-center">
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              className="w-32 h-32 rounded-full overflow-hidden border-4 border-sage-100 mx-auto mb-8 shadow-xl"
            >
              <img
                src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=400"
                alt="Gadadhar"
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </motion.div>
            <h1 className="text-5xl md:text-7xl font-serif font-bold text-stone-900 mb-4">The Founder’s Note</h1>
            <p className="text-sage-600 font-bold uppercase tracking-widest">A Growth Arc Perspective</p>
          </div>

          <div className="bg-white rounded-[60px] p-10 md:p-20 shadow-sm border border-stone-100 relative overflow-hidden">
            {/* Decorative Doodle-like element */}
            <div className="absolute -top-10 -right-10 w-40 h-40 bg-sage-50 rounded-full opacity-50 blur-2xl" />
            <div className="absolute -bottom-10 -left-10 w-40 h-40 bg-stone-100 rounded-full opacity-50 blur-2xl" />

            <div className="relative z-10 space-y-8 text-stone-600 text-lg md:text-xl leading-relaxed font-serif italic">
              <p className="font-bold text-stone-800 not-italic mb-12 text-2xl">From a Conversation to a Calling</p>
              
              <p>
                Growth Arc didn’t begin in an office; it began with a conversation between three colleagues about the complexities of the modern workplace and the human psyche. We found ourselves asking: How do we move beyond just "getting by" to truly thriving?
              </p>
              
              <p>
                As a student of Freudian thought, I have always been fascinated by the "hidden" drivers of our behavior—the internal maps that dictate our external success. It was during our 60 hours of intensive clinical postings that this fascination turned into a mission.
              </p>
              
              <p>
                Witnessing firsthand the profound shift that occurs when a person feels truly heard, we realized we couldn't just work for a firm; we had to build one.
              </p>

              <div className="py-12 border-y border-stone-100 my-12">
                <p className="text-3xl md:text-4xl text-stone-900 leading-tight">
                  "We created Growth Arc to be a bridge between where you are and where you want to be. Our philosophy is simple: we look beneath the surface to understand the roots, so you can reach for the heights."
                </p>
              </div>

              <p>
                We don't just help you move past the obstacles. We heal, and we grow. ✨
              </p>

              <div className="pt-12">
                <p className="font-bold text-stone-900 not-italic">— Gadadhar</p>
                <p className="text-sage-600 text-sm not-italic uppercase tracking-widest font-bold">Founder, Growth Arc</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </PageTransition>
  );
}
