import React, { createContext, useContext, useState, ReactNode } from 'react';

export type MoodType = 'calm' | 'overwhelmed' | 'burntout' | 'anxious';

interface MoodTheme {
  id: MoodType;
  label: string;
  color: string;
  accent: string;
  description: string;
}

export const moods: MoodTheme[] = [
  { 
    id: 'calm', 
    label: 'Calm', 
    color: '#789D9E', 
    accent: 'text-[#789D9E]',
    description: 'Ethereal Teal - Slow, rhythmic pulse' 
  },
  { 
    id: 'overwhelmed', 
    label: 'Overwhelmed', 
    color: '#9B8BB5', 
    accent: 'text-[#9B8BB5]',
    description: 'Soft Lavender - High-blur clouds' 
  },
  { 
    id: 'burntout', 
    label: 'Burnt Out', 
    color: '#C58B74', 
    accent: 'text-[#C58B74]',
    description: 'Warm Terracotta - Low-brightness sunset glow' 
  },
  { 
    id: 'anxious', 
    label: 'Anxious', 
    color: '#6B8E6D', 
    accent: 'text-[#6B8E6D]',
    description: 'Deep Sage - Static, grounded color blocks' 
  },
];

interface MoodContextType {
  currentMood: MoodTheme;
  setMood: (id: MoodType) => void;
}

const MoodContext = createContext<MoodContextType | undefined>(undefined);

export function MoodProvider({ children }: { children: ReactNode }) {
  const [currentMood, setCurrentMoodState] = useState<MoodTheme>(moods[0]);

  const setMood = (id: MoodType) => {
    const mood = moods.find(m => m.id === id);
    if (mood) {
      setCurrentMoodState(mood);
      // Update CSS variable for global use
      document.documentElement.style.setProperty('--accent-color', mood.color);
    }
  };

  return (
    <MoodContext.Provider value={{ currentMood, setMood }}>
      {children}
    </MoodContext.Provider>
  );
}

export function useMood() {
  const context = useContext(MoodContext);
  if (context === undefined) {
    throw new Error('useMood must be used within a MoodProvider');
  }
  return context;
}
