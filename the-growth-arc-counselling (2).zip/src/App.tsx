import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { AnimatePresence } from 'motion/react';
import { Suspense, lazy, useEffect } from 'react';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import CursorFollower from './components/CursorFollower';
import Soundscape from './components/Soundscape';
import ArcScrollProgress from './components/ArcScrollProgress';
import BackgroundMesh from './components/BackgroundMesh';
import Lenis from 'lenis';

import { AuthProvider } from './contexts/AuthContext';
import { MoodProvider } from './contexts/MoodContext';
import { ErrorBoundary } from './components/ErrorBoundary';

// Lazy load pages
const Home = lazy(() => import('./pages/Home'));
const About = lazy(() => import('./pages/About'));
const Team = lazy(() => import('./pages/Team'));
const Services = lazy(() => import('./pages/Services'));
const Blog = lazy(() => import('./pages/Blog'));
const FAQ = lazy(() => import('./pages/FAQ'));
const Policies = lazy(() => import('./pages/Policies'));
const Booking = lazy(() => import('./pages/Booking'));
const Founder = lazy(() => import('./pages/Founder'));

// Loading component
const PageLoader = () => (
  <div className="h-screen w-full flex items-center justify-center bg-moss-black">
    <div className="w-12 h-12 border-2 border-sage-ethereal/20 border-t-sage-ethereal rounded-full animate-spin" />
  </div>
);

function ScrollToTop() {
  const { pathname } = window.location;
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);
  return null;
}

export default function App() {
  useEffect(() => {
    const lenis = new Lenis({
      duration: 1.2,
      easing: (t) => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
      orientation: 'vertical',
      gestureOrientation: 'vertical',
      smoothWheel: true,
      wheelMultiplier: 1,
      touchMultiplier: 2,
      infinite: false,
    });

    function raf(time: number) {
      lenis.raf(time);
      requestAnimationFrame(raf);
    }

    requestAnimationFrame(raf);

    return () => {
      lenis.destroy();
    };
  }, []);

  return (
    <ErrorBoundary>
      <AuthProvider>
        <MoodProvider>
          <Router>
            <ScrollToTop />
            <CursorFollower />
            <Soundscape />
            <ArcScrollProgress />
            <BackgroundMesh />
            {/* Removed grain-overlay for performance, can be added back if optimized */}
            <div className="min-h-screen flex flex-col relative z-10">
              <Navbar />
              <main className="flex-grow">
                <Suspense fallback={<PageLoader />}>
                  <AnimatePresence mode="wait">
                    <Routes>
                      <Route path="/" element={<Home />} />
                      <Route path="/about" element={<About />} />
                      <Route path="/founder" element={<Founder />} />
                      <Route path="/team" element={<Team />} />
                      <Route path="/services" element={<Services />} />
                      <Route path="/blog" element={<Blog />} />
                      <Route path="/faq" element={<FAQ />} />
                      <Route path="/policies" element={<Policies />} />
                      <Route path="/booking" element={<Booking />} />
                    </Routes>
                  </AnimatePresence>
                </Suspense>
              </main>
              <Footer />
            </div>
          </Router>
        </MoodProvider>
      </AuthProvider>
    </ErrorBoundary>
  );
}
