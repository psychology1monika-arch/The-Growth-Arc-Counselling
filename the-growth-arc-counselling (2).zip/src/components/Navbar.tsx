import { Link, useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import { Menu, X, Heart, LogOut, ShieldAlert, Smile, Frown, Zap, Coffee, Sparkles } from 'lucide-react';
import { useState, useEffect } from 'react';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';
import { useAuth } from '../contexts/AuthContext';
import { useMood, moods, MoodType } from '../contexts/MoodContext';
import { auth, signOut } from '../firebase';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

const navLinks = [
  { name: 'Home', path: '/' },
  { name: 'Team', path: '/team' },
  { name: 'Journal', path: '/blog' },
  { name: 'Booking', path: '/booking' },
];

const moodIcons: Record<string, React.ReactNode> = {
  calm: <Smile size={14} />,
  overwhelmed: <Frown size={14} />,
  burntout: <Coffee size={14} />,
  anxious: <Zap size={14} />,
};

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const { currentMood, setMood } = useMood();
  const location = useLocation();
  const { user } = useAuth();

  useEffect(() => {
    setIsOpen(false);
  }, [location]);

  const handleSignOut = async () => {
    try {
      await signOut(auth);
    } catch (error) {
      console.error('Sign out error:', error);
    }
  };

  const quickExit = () => {
    window.location.href = 'https://www.google.com';
  };

  return (
    <nav className="fixed bottom-8 left-1/2 -translate-x-1/2 z-[100] w-[90%] max-w-4xl">
      <div className="glass-pill px-6 py-4 flex items-center justify-between gap-4 md:gap-8 border border-off-white/10">
        {/* Logo */}
        <Link to="/" className="flex items-center gap-2 group shrink-0">
          <div 
            className="w-8 h-8 rounded-full flex items-center justify-center overflow-hidden relative transition-colors duration-1000"
            style={{ backgroundColor: currentMood.color }}
          >
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
              className="absolute inset-0 border-2 border-white/20 rounded-full border-t-white"
            />
            <Heart size={14} className="text-white relative z-10" fill="currentColor" />
          </div>
          <span className="hidden lg:block font-serif font-bold text-off-white tracking-tight group-hover:text-sage-ethereal transition-colors">
            The Growth Arc
          </span>
        </Link>

        {/* Desktop Links */}
        <div className="hidden md:flex items-center gap-6">
          {navLinks.map((link) => (
            <Link
              key={link.path}
              to={link.path}
              className={cn(
                "text-[10px] font-bold uppercase tracking-[0.2em] transition-all hover:text-off-white relative py-1",
                location.pathname === link.path ? "text-off-white" : "text-off-white/40"
              )}
            >
              {link.name}
              {location.pathname === link.path && (
                <motion.div
                  layoutId="nav-underline"
                  className="absolute bottom-0 left-0 right-0 h-0.5 rounded-full"
                  style={{ backgroundColor: currentMood.color }}
                />
              )}
            </Link>
          ))}
        </div>

        {/* Mood Toggle & Actions */}
        <div className="flex items-center gap-2 md:gap-4">
          <div className="relative group">
            <button 
              className="flex items-center gap-2 px-3 md:px-4 py-2 rounded-full bg-white/5 border border-white/10 text-[10px] font-bold uppercase tracking-widest text-off-white/80 hover:bg-white/10 transition-all"
              style={{ borderColor: `${currentMood.color}33` }}
            >
              <Sparkles size={12} style={{ color: currentMood.color }} />
              <span className="hidden sm:inline">
                {currentMood.label}
              </span>
            </button>
            
            {/* Mood Dropdown */}
            <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-4 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-300">
              <div className="glass-pill p-2 flex gap-2 border border-off-white/10">
                {moods.map((mood) => (
                  <button
                    key={mood.id}
                    onClick={() => setMood(mood.id as MoodType)}
                    className={cn(
                      "p-3 rounded-full transition-all hover:scale-110",
                      currentMood.id === mood.id ? "bg-white/20" : "bg-white/5"
                    )}
                    style={{ backgroundColor: currentMood.id === mood.id ? mood.color : undefined }}
                    title={mood.label}
                  >
                    <div className="text-white">
                      {moodIcons[mood.id]}
                    </div>
                  </button>
                ))}
              </div>
            </div>
          </div>

          <Link
            to="/booking"
            className="hidden sm:flex items-center gap-2 px-6 py-2 text-white rounded-full text-[10px] font-bold uppercase tracking-widest transition-all hover:opacity-90"
            style={{ backgroundColor: currentMood.color, boxShadow: `0 0 20px ${currentMood.color}44` }}
          >
            {user ? 'My Sessions' : 'Book Now'}
          </Link>

          <button
            onClick={quickExit}
            className="p-2 rounded-full bg-red-500/10 text-red-400 hover:bg-red-500 hover:text-white transition-all"
            title="Quick Exit"
          >
            <ShieldAlert size={18} />
          </button>

          {/* Mobile Menu Toggle */}
          <button
            className="md:hidden p-2 text-off-white"
            onClick={() => setIsOpen(!isOpen)}
          >
            {isOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
            className="absolute bottom-full left-0 right-0 mb-4 md:hidden"
          >
            <div className="glass-pill p-4 flex flex-col gap-2 border border-off-white/10">
              {navLinks.map((link) => (
                <Link
                  key={link.path}
                  to={link.path}
                  onClick={() => setIsOpen(false)}
                  className={cn(
                    "px-4 py-3 rounded-2xl text-[10px] font-bold uppercase tracking-widest transition-all",
                    location.pathname === link.path ? "text-white" : "text-off-white/60 hover:bg-white/5"
                  )}
                  style={{ backgroundColor: location.pathname === link.path ? currentMood.color : undefined }}
                >
                  {link.name}
                </Link>
              ))}
              <Link
                to="/booking"
                onClick={() => setIsOpen(false)}
                className="mt-2 px-4 py-3 text-white rounded-2xl text-center font-bold uppercase tracking-widest text-[10px]"
                style={{ backgroundColor: currentMood.color }}
              >
                {user ? 'My Sessions' : 'Book a Session'}
              </Link>
              {user && (
                <button 
                  onClick={handleSignOut}
                  className="flex items-center justify-center gap-2 text-red-400 font-bold py-3 text-[10px] uppercase tracking-widest"
                >
                  <LogOut size={16} /> Sign Out
                </button>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
}
