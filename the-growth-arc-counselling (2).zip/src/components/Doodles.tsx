import React from 'react';
import { motion } from 'motion/react';

export const DoodlePlant = ({ className = "", style = {} }) => (
  <svg viewBox="0 0 100 100" className={className} style={style} fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M50,90 C50,60 30,50 30,30 C30,10 50,10 50,30 C50,10 70,10 70,30 C70,50 50,60 50,90" />
    <path d="M50,60 C65,55 75,45 75,35" />
    <path d="M50,70 C35,65 25,55 25,45" />
  </svg>
);

export const DoodleHeart = ({ className = "", style = {} }) => (
  <svg viewBox="0 0 100 100" className={className} style={style} fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M50,85 C20,70 10,40 25,25 C40,10 50,30 50,30 C50,30 60,10 75,25 C90,40 80,70 50,85" />
  </svg>
);

export const DoodleBrain = ({ className = "", style = {} }) => (
  <svg viewBox="0 0 100 100" className={className} style={style} fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M50,20 C30,20 20,35 20,50 C20,65 30,80 50,80 C70,80 80,65 80,50 C80,35 70,20 50,20" />
    <path d="M50,20 L50,80" />
    <path d="M35,35 C40,40 45,35 50,40" />
    <path d="M65,35 C60,40 55,35 50,40" />
    <path d="M35,65 C40,60 45,65 50,60" />
    <path d="M65,65 C60,60 55,65 50,60" />
  </svg>
);

export const DoodleSparkle = ({ className = "", style = {} }) => (
  <svg viewBox="0 0 100 100" className={className} style={style} fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M50,10 L50,90 M10,50 L90,50 M25,25 L75,75 M75,25 L25,75" />
  </svg>
);

export const DoodleArc = ({ className = "", style = {} }) => (
  <svg viewBox="0 0 100 100" className={className} style={style} fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M10,80 Q50,20 90,80" />
  </svg>
);

export const DoodleBook = ({ className = "", style = {} }) => (
  <svg viewBox="0 0 100 100" className={className} style={style} fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M20,20 L50,30 L80,20 L80,80 L50,90 L20,80 Z" />
    <path d="M50,30 L50,90" />
  </svg>
);

export const DoodleCoffee = ({ className = "", style = {} }) => (
  <svg viewBox="0 0 100 100" className={className} style={style} fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M30,40 L70,40 L65,80 L35,80 Z" />
    <path d="M70,50 C80,50 80,65 70,65" />
    <path d="M40,20 Q45,30 40,40 M50,20 Q55,30 50,40 M60,20 Q65,30 60,40" />
  </svg>
);

export const DoodleTangle = ({ className = "", style = {}, isHovered = false }) => (
  <svg viewBox="0 0 100 100" className={className} style={style} fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <motion.path
      d={isHovered 
        ? "M20,50 Q40,20 60,50 T100,50" 
        : "M20,50 C25,40 30,60 35,50 C40,40 45,60 50,50 C55,40 60,60 65,50 C70,40 75,60 80,50 C85,40 90,60 95,50"}
      animate={{ d: isHovered 
        ? "M10,50 Q30,50 50,50 T90,50" 
        : "M20,50 C25,30 30,70 35,50 C40,30 45,70 50,50 C55,30 60,70 65,50 C70,30 75,70 80,50 C85,30 90,70 95,50" }}
      transition={{ duration: 1.5, ease: "easeInOut" }}
    />
  </svg>
);

export const DoodleCloud = ({ className = "", style = {} }) => (
  <svg viewBox="0 0 100 100" className={className} style={style} fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M25,60 C25,45 40,40 50,45 C55,35 75,35 80,50 C90,50 90,70 80,75 L25,75 C15,75 15,60 25,60" />
  </svg>
);

export const DoodleSun = ({ className = "", style = {} }) => (
  <svg viewBox="0 0 100 100" className={className} style={style} fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <circle cx="50" cy="50" r="15" />
    <path d="M50,20 V30 M50,70 V80 M20,50 H30 M70,50 H80 M28,28 L35,35 M65,65 L72,72 M72,28 L65,35 M35,65 L28,72" />
  </svg>
);
