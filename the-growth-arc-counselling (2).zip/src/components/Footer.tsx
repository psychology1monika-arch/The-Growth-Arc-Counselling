import { Link } from 'react-router-dom';
import { Instagram, Linkedin, Heart, Mail, MapPin } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-moss-black border-t border-off-white/5 pt-24 pb-12 px-6">
      <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-16 mb-24">
        <div className="col-span-1 md:col-span-1">
          <Link to="/" className="flex items-center gap-3 mb-8">
            <div className="w-10 h-10 bg-off-white/5 rounded-full flex items-center justify-center text-off-white/60 border border-off-white/10">
              <Heart size={18} fill="currentColor" />
            </div>
            <span className="font-serif text-2xl font-bold tracking-tighter text-off-white">
              The Growth Arc
            </span>
          </Link>
          <p className="text-off-white/40 text-base leading-relaxed mb-8 italic font-light">
            "Healing is the bridge between who you are and who you are becoming."
          </p>
          <div className="flex gap-5">
            <a
              href="https://www.instagram.com/the_growth_arc_counselling"
              target="_blank"
              rel="noopener noreferrer"
              className="w-12 h-12 rounded-full border border-off-white/10 flex items-center justify-center text-off-white/40 hover:bg-off-white/5 hover:text-off-white hover:border-off-white/30 transition-all"
            >
              <Instagram size={20} />
            </a>
            <a
              href="https://www.linkedin.com/in/the-growth-arc-counselling-7851903b4"
              target="_blank"
              rel="noopener noreferrer"
              className="w-12 h-12 rounded-full border border-off-white/10 flex items-center justify-center text-off-white/40 hover:bg-off-white/5 hover:text-off-white hover:border-off-white/30 transition-all"
            >
              <Linkedin size={20} />
            </a>
          </div>
        </div>

        <div>
          <h4 className="text-[10px] font-bold uppercase tracking-[0.4em] text-off-white/20 mb-8">Quick Links</h4>
          <ul className="space-y-5">
            <li><Link to="/about" className="text-off-white/40 hover:text-off-white transition-colors text-sm font-medium">About Us</Link></li>
            <li><Link to="/team" className="text-off-white/40 hover:text-off-white transition-colors text-sm font-medium">Our Team</Link></li>
            <li><Link to="/services" className="text-off-white/40 hover:text-off-white transition-colors text-sm font-medium">Services</Link></li>
            <li><Link to="/blog" className="text-off-white/40 hover:text-off-white transition-colors text-sm font-medium">Blog</Link></li>
          </ul>
        </div>

        <div>
          <h4 className="text-[10px] font-bold uppercase tracking-[0.4em] text-off-white/20 mb-8">Support</h4>
          <ul className="space-y-5">
            <li><Link to="/faq" className="text-off-white/40 hover:text-off-white transition-colors text-sm font-medium">FAQs</Link></li>
            <li><Link to="/policies" className="text-off-white/40 hover:text-off-white transition-colors text-sm font-medium">Privacy Policy</Link></li>
            <li><Link to="/policies" className="text-off-white/40 hover:text-off-white transition-colors text-sm font-medium">Terms of Service</Link></li>
            <li><Link to="/policies" className="text-off-white/40 hover:text-off-white transition-colors text-sm font-medium">Cancellation Policy</Link></li>
          </ul>
        </div>

        <div>
          <h4 className="text-[10px] font-bold uppercase tracking-[0.4em] text-off-white/20 mb-8">Contact</h4>
          <ul className="space-y-6">
            <li className="flex items-start gap-4 text-off-white/40 text-sm leading-relaxed">
              <MapPin size={20} className="text-off-white/20 shrink-0" />
              <span>Based in Chennai,<br />serving across India</span>
            </li>
            <li className="flex items-center gap-4 text-off-white/40 text-sm">
              <Mail size={20} className="text-off-white/20 shrink-0" />
              <span>contact@thegrowtharc.com</span>
            </li>
          </ul>
        </div>
      </div>

      <div className="max-w-7xl mx-auto mb-16 p-10 bg-off-white/5 border border-off-white/10 rounded-[40px] text-center relative overflow-hidden group">
        <div className="absolute inset-0 bg-red-500/5 opacity-0 group-hover:opacity-100 transition-opacity duration-1000" />
        <p className="text-off-white/40 text-sm leading-relaxed relative z-10 max-w-2xl mx-auto">
          <span className="font-bold text-red-500/60 uppercase tracking-[0.4em] text-[10px] block mb-4">Crisis Disclaimer</span>
          We are not a crisis intervention service. If you are feeling suicidal, please call <span className="font-bold text-off-white/80">[Kiran: 1800-599-0019]</span> or visit the nearest ER. Your safety is paramount.
        </p>
      </div>

      <div className="max-w-7xl mx-auto pt-12 border-t border-off-white/5 flex flex-col md:flex-row justify-between items-center gap-6">
        <p className="text-off-white/20 text-[10px] uppercase tracking-[0.3em] font-bold">
          © {new Date().getFullYear()} The Growth Arc Counselling. All rights reserved.
        </p>
        <p className="text-off-white/20 text-[10px] uppercase tracking-[0.5em] font-bold italic">
          Healing That Honors You
        </p>
      </div>
    </footer>
  );
}

