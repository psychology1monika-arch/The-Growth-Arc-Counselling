import { motion, useScroll, useSpring, useTransform } from 'motion/react';

export default function ArcScrollProgress() {
  const { scrollYProgress } = useScroll();
  
  // Create a spring for smooth progress
  const scaleX = useSpring(scrollYProgress, {
    stiffness: 100,
    damping: 30,
    restDelta: 0.001
  });

  return (
    <div className="fixed top-8 right-8 z-[100] w-24 h-24 pointer-events-none">
      <svg viewBox="0 0 100 100" className="w-full h-full transform -rotate-90">
        {/* Background Arc */}
        <path
          d="M 20,50 A 30,30 0 1,1 80,50"
          fill="none"
          stroke="rgba(255,255,255,0.05)"
          strokeWidth="2"
          strokeLinecap="round"
        />
        {/* Progress Arc */}
        <motion.path
          d="M 20,50 A 30,30 0 1,1 80,50"
          fill="none"
          stroke="#D4A373" // Gold/Clay color
          strokeWidth="2"
          strokeLinecap="round"
          style={{
            pathLength: scrollYProgress,
          }}
        />
      </svg>
      <div className="absolute inset-0 flex items-center justify-center">
        <span className="text-[10px] font-mono text-clay-muted uppercase tracking-widest">
          Arc
        </span>
      </div>
    </div>
  );
}
