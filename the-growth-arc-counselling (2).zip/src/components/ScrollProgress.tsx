import { useEffect, useState } from 'react';
import { motion, useScroll, useSpring } from 'motion/react';
import { ArrowUp } from 'lucide-react';

export default function ScrollProgress() {
  const [isVisible, setIsVisible] = useState(false);
  const { scrollYProgress } = useScroll();
  const scaleX = useSpring(scrollYProgress, {
    stiffness: 100,
    damping: 30,
    restDelta: 0.001
  });

  useEffect(() => {
    const toggleVisibility = () => {
      if (window.pageYOffset > 300) {
        setIsVisible(true);
      } else {
        setIsVisible(false);
      }
    };

    window.addEventListener('scroll', toggleVisibility);
    return () => window.removeEventListener('scroll', toggleVisibility);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: 'smooth',
    });
  };

  return (
    <>
      {/* Top Progress Bar */}
      <motion.div
        className="fixed top-0 left-0 right-0 h-1 bg-gold-muted z-[100] origin-left"
        style={{ scaleX }}
      />

      {/* Circular Arc Indicator */}
      <div className="fixed bottom-6 right-6 z-50">
        <div className="relative w-16 h-16 flex items-center justify-center">
          <svg className="w-full h-full transform -rotate-90">
            <circle
              cx="32"
              cy="32"
              r="28"
              stroke="currentColor"
              strokeWidth="4"
              fill="transparent"
              className="text-stone-200"
            />
            <motion.circle
              cx="32"
              cy="32"
              r="28"
              stroke="currentColor"
              strokeWidth="4"
              fill="transparent"
              strokeDasharray="175.9"
              style={{ pathLength: scrollYProgress }}
              className="text-sage-deep"
            />
          </svg>
          <button
            onClick={scrollToTop}
            className={`absolute inset-0 flex items-center justify-center text-sage-deep transition-opacity duration-300 ${
              isVisible ? 'opacity-100' : 'opacity-0 pointer-events-none'
            }`}
          >
            <ArrowUp size={20} />
          </button>
        </div>
      </div>
    </>
  );
}
